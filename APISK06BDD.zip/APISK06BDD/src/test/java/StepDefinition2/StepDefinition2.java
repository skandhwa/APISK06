package StepDefinition2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition2 {
	
	@Before
	public void beforeHooksDBConnection()
	
	{
		System.out.println("Code for connection with DB");
	}
	
	@After
	public void AfterHooksDBConnection()
	
	{
		System.out.println("Code to disconnect  with DB");
	}
	
	@Before("@test1")
	public void beforeTest1()
	{
		System.out.println("Before test1 scenario");
	}
	
	
	@After("@test1")
	public void afterTest1()
	{
		System.out.println("After test1 scenario");
	}
	
	
	
	
	@Given("user opens the browser and enters the url and hit enter")
	public void user_opens_the_browser_and_enters_the_url_and_hit_enter() {
	    
		System.out.println("Hello ");
		
	}

	@Given("user enters username in {string} field")
	public void user_enters_username_in_field(String string) {
	   
		System.out.println("Uname entered ");
	}

	@Given("user enters password in {string} field")
	public void user_enters_password_in_field(String string) {
		System.out.println("Password entered ");
		
		
	}

	@When("user clicks on submit button")
	public void user_clicks_on_submit_button() {
	    
		System.out.println("Submit button clicked ");
	}

	@Then("user will be able to home page of the application")
	public void user_will_be_able_to_home_page_of_the_application() {
	    
		System.out.println("Home page navigated");
		
	}
	
	@Then("user will get an error message as invalid user")
	public void user_will_get_an_error_message_as_invalid_user() {
	   
		System.out.println("Incorrect user id or password");
		
	}
	
	
	@Given("user opens the demo website of grotechMinds")
	public void user_opens_the_demo_website_of_grotech_minds() {
	   
		System.out.println("Application launched");
	}

	@Given("user enters the below details")
	public void user_enters_the_below_details(io.cucumber.datatable.DataTable userCredentials) {
	    
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
List<List<String>> data=userCredentials.asLists(String.class);

driver.findElement(By.xpath("(//input[@placeholder='First Name'])[1]")).sendKeys(data.get(1).get(0));
driver.findElement(By.xpath("(//input[@placeholder='Last Name'])[1]")).sendKeys(data.get(1).get(1));
		
		
	}


}
