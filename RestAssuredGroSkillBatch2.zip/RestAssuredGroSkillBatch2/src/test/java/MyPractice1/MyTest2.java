package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

public class MyTest2 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		String Actual_firstName="Michael";
		
	String Response=	given().log().all().queryParam("page",2)
		.when().get("api/users").then().assertThat().statusCode(200)
		.extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
String Expected_firstname=	js.get("data[0].first_name");

Assert.assertEquals(Actual_firstName, Expected_firstname);




	
		

	}

}
