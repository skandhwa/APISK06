package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


import static io.restassured.RestAssured.*;

import org.testng.Assert;

public class BasicEx1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		int ActualID=2;
		
String Response=		given().log().all().
		
		
		when().get("api/users/2").
		
		
		then().log().all().extract().response().asString();


System.out.println(Response);

JsonPath js=new JsonPath(Response);

int ExpectedID=js.get("data.id");

System.out.println("The ID value is  "+ExpectedID);

Assert.assertEquals(ActualID,ExpectedID );








		
		
		
		
		

	}

}
