package Payload;

public class TestData1 {
	
	public static String AddDetails(String name,String jobrole)
	{
		String payload="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+jobrole+"\"\r\n"
				+ "}";
		
		return payload;
		
	}
	
	
	

}
