package ArrayListExample;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExample {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		
		q1.add(34);
		q1.add(67);
		q1.add(89);
		q1.add(99);
		
		q1.remove();
		q1.remove();
		
		System.out.println(q1);
		

	}

}
