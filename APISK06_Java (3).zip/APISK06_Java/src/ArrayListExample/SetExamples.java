package ArrayListExample;

import java.util.HashSet;
import java.util.Set;

public class SetExamples {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Guava");
		s1.add("Papaya");
		s1.add("Orange");
		
		System.out.println(s1);
		
		Set<String> s2=new HashSet<String>();
		s2.add("Kiwi");
		s2.add("Grapes");
		s2.add("banana");
		s2.add("Guava");
		
		s1.addAll(s2);
		
		
		
		System.out.println(s1);
		
		
		
		

	}

}
