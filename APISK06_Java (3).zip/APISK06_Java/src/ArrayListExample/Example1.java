package ArrayListExample;

import java.util.ArrayList;
import java.util.Iterator;

public class Example1 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(96);
		li.add(102);
		li.add(78);
		
		System.out.println(li);
		
		for(int x:li)
		{
			System.out.println(x);
		}
		
		Iterator itr=li.iterator();
		
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		
		
		
		

	}

}
