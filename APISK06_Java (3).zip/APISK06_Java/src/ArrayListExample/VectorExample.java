package ArrayListExample;

import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(45);
		v.add(98);
		v.add(105);
		System.out.println(v);
		
		

	}

}

