package ArrayListExample;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class SetExample4 {

	public static void main(String[] args) {
		Set<String> s1=new HashSet<String>();
		s1.add("Mango");
		s1.add("Guava");
		s1.add("Papaya");
		s1.add("Orange");
		s1.add("Mango");
		
		ArrayList<String> li=new ArrayList<String>();
		for(String x:s1)
		{
			li.add(x);
		}
		
		for(String y:li)
		{
			System.out.println(y);
		}
		

	}

}
