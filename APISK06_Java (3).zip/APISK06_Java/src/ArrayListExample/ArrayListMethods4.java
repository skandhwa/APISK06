package ArrayListExample;

import java.util.ArrayList;

public class ArrayListMethods4 {

	public static void main(String[] args) {
		
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(96);
		li.add(102);
		li.add(88);
		
		li.clear();
		
	boolean flag2=	li.isEmpty();
	System.out.println("Is the list empty  "+flag2);
		
		
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(23);
		li2.add(78);
		li2.add(89);
		
	boolean flag=	li.containsAll(li2);
	
	System.out.println(flag);
	
	
	

	}

}
