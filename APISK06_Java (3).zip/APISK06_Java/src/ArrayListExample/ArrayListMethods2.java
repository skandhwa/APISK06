package ArrayListExample;

import java.util.ArrayList;

public class ArrayListMethods2 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("melon");
		li.add("orange");
		li.add("kiwi");
		li.add("apple");
		
	boolean flag=	li.contains("apple");
	
	System.out.println("Does the list contains apple "+flag);
	
	String value=li.get(2);
	System.out.println("element at index 2 is "+value);
	
	li.set(3,"mango");
	
	System.out.println("After updating the list is "+li);
	
	li.add(2,"lemon");
	System.out.println("Adding lemon in second index "+li);
	
	
	
	
	
		
		
		System.out.println(li);
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("banana");
		li2.add("pine");
		li2.add("grapes");
		
		li.addAll(li2);
		
		System.out.println("after merging elements are");
		
		System.out.println(li);
		
		

	}

}
