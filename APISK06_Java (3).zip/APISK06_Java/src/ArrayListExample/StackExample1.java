package ArrayListExample;

import java.util.Stack;

public class StackExample1 {

	public static void main(String[] args) {
		
		Stack<Integer> s=new Stack<Integer>();
		s.push(34);
		s.push(89);
		s.push(99);
		s.push(101);
		s.pop();
		s.pop();
		
		System.out.println(s);
		
	int x=	s.peek();
	System.out.println("Peek of stack is  "+x);
		
		

	}

}
