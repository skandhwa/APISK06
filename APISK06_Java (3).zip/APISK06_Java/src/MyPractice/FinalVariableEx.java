package MyPractice;

class Test3
{
	final int speed=40;
	public void test()
	{
		// speed=60;
		System.out.println(speed);
	}
	
}





public class FinalVariableEx {

	public static void main(String[] args) {
		
		Test3 obj=new Test3();
		obj.test();
		

	}

}
