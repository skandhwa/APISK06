package MyPractice;

public class ThrowsExample {

	public static void main(String[] args) throws InterruptedException  {
		
		Thread.sleep(3000);
		
		

	}

}
