package MyPractice;

final class B
{
	void test()
	{
		System.out.println("Hello");
	}
}

class C extends B
{
	void test1()
	{
		System.out.println("Hi");
	}
}




public class FinalClassEx {

	public static void main(String[] args) {
		

	}

}
