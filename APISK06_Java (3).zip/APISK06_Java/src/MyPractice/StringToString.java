package MyPractice;

public class StringToString {

	public static void main(String[] args) {
		
		
		int x=10;
	String str1=	String.valueOf(x); 
	
	System.out.println(str1);
		

	}

}
