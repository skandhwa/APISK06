package MyPractice;

class Test2
{
	static void test()
	{
		System.out.println("Hello how r u");
	}
}




public class StaticMethodsExample {

	public static void main(String[] args) {
		
		Test2.test();

	}

}
