package MyPractice;

public class FibbonaciSeriesEx {

	public static void main(String[] args) {
		
		
		int n1=0;
		int n2=1;
		System.out.print(n1 +" "+n2);//0  1
		
		for(int i=2;i<10;i++)///i=2,2<10//i=3,3<10
		{
			int n3=n1+n2;///n3=0+1=1//n3=1+1
			
			
			System.out.print(" "+n3);///1
			
			n1=n2;//n1=1//n1
			n2=n3;//n2=1
			
		}
		
		
		
		

	}

}
