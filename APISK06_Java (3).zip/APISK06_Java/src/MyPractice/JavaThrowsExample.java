package MyPractice;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

class H
{
	public static void getAccess(int empID) throws FileNotFoundException
	{
		if(empID==76566)
		{
		
		FileReader f=new FileReader("C:\\Users\\saura\\OneDrive\\Documents\\Assignment 04.txt");
		BufferedReader fileInput=new BufferedReader(f);
		System.out.println("Data read successfull");
		
	}
		else
		{
			throw new FileNotFoundException("File access denied");
		}
		
		
	}
		
}





public class JavaThrowsExample {

	public static void main(String[] args) throws FileNotFoundException {
		
		H.getAccess(78566);
		
		
		
		

	}

}
