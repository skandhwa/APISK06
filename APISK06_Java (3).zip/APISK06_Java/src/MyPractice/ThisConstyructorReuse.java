package MyPractice;

class E
{
	int id;
	String name;
	String address;
	
	E(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	E(int id,String name,String address)
	{
		this(id,name);
		this.address=address;
		
	}
	
	void display()
	{
		System.out.println(id+" "+name+" "+address);
	}
	
}




public class ThisConstyructorReuse {

	public static void main(String[] args) {
		
		E obj=new E(123,"Saurabh");
		obj.display();
		
		E obj1=new E(423,"gaurabh","Mumbai");
		obj1.display();

	}

}
