package MyPractice;

public class LoopingConcepts {

	public static void main(String[] args) {
		
		int x=20;
		int y=30%2;
		
		
		if(x>10 && y>10 && x>y )// 20>10...
		{
			System.out.println("This is true");
		}
		

	}

}
