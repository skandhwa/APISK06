package MyPractice;

public class forLoopEx {

	public static void main(String[] args) {
		
		for(int i=1;i<=5;i++)//i=1... 1<=5...2<=5...3<=5
		{
			System.out.println(i);//1//2//3//4//5
			;//1++ //2++
		}
		

	}

}
