package MyPractice;

public class ArrayMaxMin {
	
	public static  int largeorSmall(int []a,int length)
	{
		for(int i=0;i<a.length;i++)///i=1,1<4
		{
			for(int j=i+1;j<a.length;j++)///
			{
				if(a[i]>a[j])///a[0]>a[3]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		return a[3-1];
	}
	
	
	
	

	public static void main(String[] args) {
		
		
		int b[]= {12,4,19,6,78,7,90};
		int x=b.length;
		
		int fourthLargest=ArrayMaxMin.largeorSmall(b, x);
		System.out.println(fourthLargest);
		
		
		

	}

}
