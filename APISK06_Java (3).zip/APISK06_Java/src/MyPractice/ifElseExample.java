package MyPractice;

public class ifElseExample {

	public static void main(String[] args) {
		
		int a=20;
		int b=40;
		
		if(a>b)
		{
			System.out.println("a is maximum");
		}
		
		else
		{
			System.out.println("b is maximum");
		}
		

	}

}
