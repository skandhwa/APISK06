package MyPractice;

public class ArrayIndexOutOfBoundsException {

	public static void main(String[] args) {
		
		try
		{
		
		int []a= {23,12,45,67,88,99};
		System.out.println(a[10]);
		
		int y=20;
		int b=30;
		int c=y+b;
		
		System.out.println(c);
		}
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		

	}

}
