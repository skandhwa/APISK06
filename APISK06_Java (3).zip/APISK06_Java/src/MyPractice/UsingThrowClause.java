package MyPractice;

class G
{
	public static void validateAge(int age)
	{
		if(age<18)
		{
			throw new ArithmeticException("Age is less than 18 years") ;
		}
		else
		{
			System.out.println("Valid age");
		}
		
		System.out.println("Vote casted successfully");
		
	}
}




public class UsingThrowClause {

	public static void main(String[] args) {
		
		G.validateAge(23);
		
		
		

	}

}
