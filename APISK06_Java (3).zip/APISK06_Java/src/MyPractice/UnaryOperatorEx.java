package MyPractice;

public class UnaryOperatorEx {

	public static void main(String[] args) {
		
		//// 30 ,14,41, 33,42,29, 32
		int a=13;
		int b=7;
		
		
		int c= b-- + a++  + ++b  - --a  + b++ + ++b;
		
		// 7+ 13 + 7 - 13 + 7 + 9
		
		// b=8,a=13
		
		
		System.out.println(c);
		
		
		
		
		
		
		
		
		
//	int z=	y++;//   postfix  increment operator
//	
//	
//	int k=--y;  //// prefix decrement operator
//	
//	int l=y-- ; ////postfix decrement
//	
//	int h=++y; ///prefix increment 
	
	
		

	}

}
