package ArrayListExample;

import java.util.ArrayList;

public class ArrayListCloneMethod {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(96);
		li.add(102);
		li.add(78);
		
		//ArrayList<Integer> li=new ArrayList<Integer>();
		ArrayList<Integer> clonedList=(ArrayList<Integer>)li.clone();
		
		System.out.println(clonedList);
		
		
		
		
		
		

	}

}
