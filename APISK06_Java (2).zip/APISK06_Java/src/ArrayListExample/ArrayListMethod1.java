package ArrayListExample;

import java.util.ArrayList;

public class ArrayListMethod1 {

	public static void main(String[] args) {
		
		ArrayList<Object> li=new ArrayList<Object>();
		li.add("Mango");
		li.add(23);
		li.add(false);
		li.add('H');
		li.add(78.98667);
		
	int x=	li.size();
	System.out.println("The size of list is  "+x);
	
	for(Object y:li)
	{
		System.out.println(y);
	}
	
	
	li.remove(3);
	System.out.println("Removing element at index 3 "+li);
	
	
	li.clear();
	
	System.out.println("After clearing elements are  "+li);
	
		
		
		
		

	}

}
