package ArrayListExample;

import java.util.ArrayList;

public class ArrayListMethods3 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(96);
		li.add(102);
		li.add(88);
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(23);
		li2.add(178);
		li2.add(196);
		li2.add(102);
		li2.add(278);
		
		
//		li2.removeAll(li);
//		System.out.println(li2);
		
		
	boolean flag=	li.containsAll(li2);
	System.out.println(flag);
		

	}

}
