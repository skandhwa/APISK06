package ArrayListExample;

import java.util.ArrayList;

public class ArrayListMethods5 {

	public static void main(String[] args) {
		
		ArrayList<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(78);
		li.add(96);
		li.add(102);
		li.add(88);
		
		ArrayList<Integer> li2=new ArrayList<Integer>();
		li2.add(23);
		li2.add(78);
		li2.add(89);
		li2.add(90);
		
		
		li2.retainAll(li);
		System.out.println(li2);
		
		
		
		

	}

}
