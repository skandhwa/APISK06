package MyPractice;

public class ArraySortingEx {

	public static void main(String[] args) {
		
		int []a= {56,45,33,12};
		
		for(int i=0;i<a.length;i++)///i=1,1<4
		{
			for(int j=i+1;j<a.length;j++)///
			{
				if(a[i]>a[j])///a[0]>a[3]
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		System.out.println("After sorting elements are ");
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
		
		
		
		
		
		

	}

}
