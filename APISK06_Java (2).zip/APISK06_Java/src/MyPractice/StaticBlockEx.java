package MyPractice;



public class StaticBlockEx {
	
	void display()
	{
		System.out.println("Hey are u fine");
	}
	
	static
	{
		System.out.println("Hi How r u");
	}


	public static void main(String[] args) {
		
		
		StaticBlockEx obj=new StaticBlockEx();
		obj.display();
		System.out.println("Hello");
		
		
		
		
		
		

	}

}
