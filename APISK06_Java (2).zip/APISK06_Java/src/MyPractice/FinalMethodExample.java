package MyPractice;

class Bank
{
	final public void getROI()
	{
		System.out.println("Rate is "+10);
	}
}

class SBI extends Bank
{
	public void getROI()
	{
		System.out.println("Rate is "+8);
	}
}

class HDFC extends Bank
{
	public void getROI()
	{
		System.out.println("Rate is "+9);
	}
}



public class FinalMethodExample {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
		obj.getROI();
		
		SBI obj1=new SBI();
		obj1.getROI();
		

	}

}
