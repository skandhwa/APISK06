package MyPractice;

class Test
{
	int id;
	String name;
	 static String companyName="TCS";
	
	Test(int id,String name)
	{
		this.id=id;
		this.name=name;
		
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+companyName);
	}
	
	
}



public class StaticVariablesEx {

	public static void main(String[] args) {
		
		Test obj=new Test(1234,"Saurabh");
		obj.display();
		Test obj1=new Test(5234,"Gaurabh");
		obj1.display();
		Test obj2=new Test(7623,"mahesh");
		obj2.display();

	}

}
