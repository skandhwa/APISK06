package MyPractice;

public class ifElseLadder {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		int c=30;
		int d=40;
		
		if(a>b && a>c && a>d)
		{
			System.out.println("a is maximum");
		}
		else if(b>a && b>c && b>d)
		{
			System.out.println("b is maximum");
		}
		
		else if(c>a && c>b && c>d)
		{
			System.out.println("c is maximum");
		}
		
		else
		{
			System.out.println("d is maximum");
		}
		
				
		

	}

}
