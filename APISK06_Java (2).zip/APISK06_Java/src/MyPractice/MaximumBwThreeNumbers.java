package MyPractice;

public class MaximumBwThreeNumbers {

	public static void main(String[] args) {
		
		int a=100;
		int b=20;
		int c=30;
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println(" a is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
		

	}

}
