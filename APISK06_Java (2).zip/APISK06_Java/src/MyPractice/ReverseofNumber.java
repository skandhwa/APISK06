package MyPractice;

public class ReverseofNumber {

	public static void main(String[] args) {
		
		
		int num=678;
		int rev=0;
		
		
		while(num!=0)//678!=0//67!=0//6!=0
		{
			int digit=num%10;//digit=678%10=8//digit=67%10=7///digit=6%10=6
			rev=rev*10+digit;///rev=0+8=8//rev=8*10+7=87//rev=87*10+6=876
			num=num/10;///num=678/10=67///67/10=6//num=6/10=0
			
			
		}
		
		System.out.println(rev);
		

	}

}
