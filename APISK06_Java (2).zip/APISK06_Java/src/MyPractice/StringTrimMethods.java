package MyPractice;

public class StringTrimMethods {

	public static void main(String[] args) {
		
		String str="        Hello      ";
		str=str.trim();
		System.out.println(str);
		

	}

}
