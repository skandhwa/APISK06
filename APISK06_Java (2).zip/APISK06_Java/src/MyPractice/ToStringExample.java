package MyPractice;

public class ToStringExample {

	public static void main(String[] args) {
		
		Integer x=5;
		
		System.out.println(x.toString());
		
		
		System.out.println(Integer.toString(12));

	}

}
