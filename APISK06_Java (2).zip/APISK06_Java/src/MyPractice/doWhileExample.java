package MyPractice;

public class doWhileExample {

	public static void main(String[] args) {
		
		int i=15;
		do
		{
			System.out.println(i);
			i++;
		}
		
		while(i<10);
		
		
		

	}

}
