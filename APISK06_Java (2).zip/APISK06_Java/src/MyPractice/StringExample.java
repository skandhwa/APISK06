package MyPractice;

public class StringExample {

	public static void main(String[] args) {
		
		String str1="Saurabh"; ///Using String literal
		
		//String str=new String("Saurabh"); ///Using new keyword
		
	str1=	str1.concat("QA tester");
		
		System.out.println(str1);
		

	}

}
