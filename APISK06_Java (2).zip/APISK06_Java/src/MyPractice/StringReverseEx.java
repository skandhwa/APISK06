package MyPractice;

public class StringReverseEx {

	public static void main(String[] args) {
		
		String str="madam";
		str=str.toLowerCase();
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)///i=6,6>=0
		{
			revstr=revstr+str.charAt(i);
		}
		
		
		System.out.println(revstr);
		
		if(str.equalsIgnoreCase(revstr))
		{
			System.out.println("String is palindrome");
		}
		else
		{
			System.out.println("Not palindrome");
		}
		
		

	}

}
