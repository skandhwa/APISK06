package MyPractice;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="India";
		char ch=str.charAt(3);
		
		System.out.println(ch);
		
	str=	str.toLowerCase();
		
		System.out.println(str);
		
		
		
		
		

	}

}
