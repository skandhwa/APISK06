package MyPractice;

public class ArrayExceptionExamples {

	public static void main(String[] args) {
		
		try
		{
		int y=20/0;
		System.out.println(y);
		}
		
		
		catch(ArithmeticException e)
		{
			System.out.println("Caught with  "+e);
		}
		
		int a=20;
		int b=30;
		int c=a+b;
		
		System.out.println(c);
		
		
		

	}

}
