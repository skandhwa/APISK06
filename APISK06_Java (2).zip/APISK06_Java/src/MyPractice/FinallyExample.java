package MyPractice;

public class FinallyExample {

	public static void main(String[] args) {
		
		try
		{
		int x=90/0;
		System.out.println(x);
		}
		
		
		
		
		
		
		finally
		{
		int a=20;
		int b=30;
		int c=a+b;
		
		System.out.println(c);
		}
		
		
		
		
		
		
		

	}

}
