package MyPractice;

import java.util.Arrays;

public class ArrayMethods1 {

	public static void main(String[] args) {
		
		int []a= {92,45,78,99};
		
		int []b= {112,45,78,99};
		
		int x=a.length;
		
		System.out.println("The length of array is  "+x);
		
		
		
	boolean flag=	Arrays.equals(a,b);
	
	System.out.println("Are two arrays equal  "+flag);
	
int y=	Arrays.compare(a,b);

System.out.println(y);


	
	
		

	}

}
