package MyPractice;

import java.util.Arrays;

public class StringAnagram {

	public static void main(String[] args) {
		String str="brag";
		String str1="grab";
		
		str=str.toLowerCase();
		str1=str1.toLowerCase();
		
		if(str.length()!=str1.length())
		{
			System.out.println("String is not anagram");
		}
		else
		{
			char []ch1=str.toCharArray();
			char []ch2=str1.toCharArray();
			Arrays.sort(ch1);
			Arrays.sort(ch2);
			
			if(Arrays.equals(ch1,ch2)==true)
			{
				System.out.println("String is anagram");
			}
			
			else
			{
				System.out.println("Not Anagram");
			}
			
		}

	}

}
