package MyPractice;

public class ArithmetiOperatorsEx {

	public static void main(String[] args) {
		
		
		int a=20;
		int b=3;
		
		int c= 20%3;
		
		System.out.println(c);
		

	}

}
