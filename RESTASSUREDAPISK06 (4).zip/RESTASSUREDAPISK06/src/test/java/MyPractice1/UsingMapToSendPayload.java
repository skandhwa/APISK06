package MyPractice1;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.LinkedHashMap;
import java.util.Map;

import org.testng.Assert;

import PayloadData.payloadData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

public class UsingMapToSendPayload {

	public static void main(String[] args) {
		
		
		String ActualCreatedDate="2025-03-25";
		
		RestAssured.baseURI="https://reqres.in";
		
		Map<String,Object> mp= new LinkedHashMap<String,Object>();
		mp.put("name", "morpheus");
		mp.put("job", "leader");
		mp.put("IsMarried", true);
		mp.put("salary", 89000f);
		
		
		String Response=given().log().all().body(mp).
		headers("Content-Type","application/json")
				.when().post("api/users")
				.then().log().all().
				assertThat().statusCode(201).
				body("job",equalTo("leader")).
				
				extract().response().asString();
				

		System.out.println(Response);
		
		JsonPath js=new JsonPath(Response);
		
	String Expected_CreatedAt=	js.getString("createdAt");
		System.out.println(Expected_CreatedAt);
		
String []s1=		Expected_CreatedAt.split("T");

String s2=s1[0].toString();
		
//System.out.println(s1[0].toString());


Assert.assertEquals(ActualCreatedDate, s2);

	}

}
