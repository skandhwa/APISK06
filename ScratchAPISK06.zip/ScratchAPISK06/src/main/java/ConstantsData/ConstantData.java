package ConstantsData;

public class ConstantData {
	
	public final static String PropertyFilePath="src/main/java/Global.properties";
	public static final String ExcelDataPath1="E:\\TestData10thApril.xlsx";
	public static final String SheetName="Sheet1";
	

}
