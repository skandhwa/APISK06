package MyPractice;

import java.util.Arrays;

public class ArrayMethods2 {

	public static void main(String[] args) {
		
		
		int []a= {92,45,78,99};
		
	Arrays.sort(a);
	
	
	for(int i=0;i<a.length;i++)
	{
		System.out.println(a[i]);
	}
		
	
	///int []b=new int[4]
	
	
	int []b=new int[a.length];
	
	System.out.println("After copying elements are");
	
	for(int i=0;i<a.length;i++)
	{
		b[i]=a[i];
		System.out.println(b[i]);
	}
	
//	for(int i=0;i<a.length;i++)
//	{
//		
//	}
	
	

	}

}
