package MyPractice;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="TestEnvironmentdstgduatdsit";
		
		String []str1=str.split(" ");
		
		System.out.println(str1[2]);
		
		
		

	}

}
