//package MyPractice;
//
//public class MyTest1 {
//
//	public static void main(String[] args) {
//		
//		boolean y=true;
//		
//		int x=21312233212;
//		
//		byte z=-129;
//		
//		short p=-3266;
//		
//		long q=1332332342432422L;
//		
//		float k=2312321322432431321.1232132132324324321312F;
//		
//		double n=232432432432432432.2343243243243243243243243243243;
//		
//		char b='A';
//		
//
//	}
//
//}
