package MyPractice;

public class ArrayExamples {

	public static void main(String[] args) {
		
		int a[]= {3,4,5,7,8,9};
		
		//int []b=new int[] {12,5,6,1,45};
		
		for(int i=0;i<a.length;i++)////i=0,0<5//i=1,1<5
		{
			System.out.println(a[i]);//a[0]//a[1]
		}
		
		
		
		
		
		
		

	}

}
