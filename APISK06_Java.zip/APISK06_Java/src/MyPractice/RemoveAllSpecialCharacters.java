package MyPractice;

public class RemoveAllSpecialCharacters {

	public static void main(String[] args) {
		String str="abcss@*&^nbh";
		
		str=str.replaceAll("[^a-zA-Z0-9]", "");
		System.out.println(str);
		
		
		//s    n    m    k
		
		
		String str2="s  n  m  k";
		str2=str2.replaceAll("  ","");
		System.out.println(str2);
		

	}

}
