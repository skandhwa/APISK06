package MyPractice;

class D
{
	int id;
	String name;
	String address;
	
	D(int id,String name,String address)
	{
		this.id=id;
		this.name=name;
		this.address=address;
	}
	
	void display()
	{
		System.out.println(id+"  "+name+"  "+address);
	}
	
}



public class ThisKeyWordExample {

	public static void main(String[] args) {
		
		D obj=new D(1234,"Saurabh","Bangalore");
		obj.display();
		
		
		

	}

}
