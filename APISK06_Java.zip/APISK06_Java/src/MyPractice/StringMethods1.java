package MyPractice;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="Republic";
		
//		int x=str.length();
//		
//		System.out.println(x);
		
		
//String	str1=	str.substring(2);
//
//System.out.println(str1);

		
		String str2=str.substring(4,7);

		System.out.println(str2);
		
		
		
		
		
		
		
		

	}

}
