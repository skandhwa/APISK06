package MyPractice;

public class StringMethods3 {

	public static void main(String[] args) {
		
		String str="Saurabh";
	    char []ch= str.toCharArray();
	    
	  //  System.out.println(ch);
	    
	    for(int i=0;i<ch.length;i++)
	    {
	    	System.out.print(ch[i]+"  ");
	    }
	    
	    
	    
		
		
		

	}

}
