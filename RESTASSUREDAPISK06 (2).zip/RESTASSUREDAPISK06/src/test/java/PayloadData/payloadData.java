package PayloadData;

public class payloadData {
	
	public static String addDetails(String name,String jobrole)
	{
		String payload="{\r\n"
				+ "    \"name\": \""+name+"\",\r\n"
				+ "    \"job\": \""+jobrole+"\"\r\n"
				+ "}";
		
		return payload;
	}
	
	
	public static String AddBook(String isbn,String aisle,String author)
	{
		String bookData="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\""+author+"\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookData;
		
	}
	
	
	

}
