package AbstractionConcepts;

abstract class Shape
{
	
	abstract void draw();
}

class Rectangle extends Shape
{
	void draw()
	{
		
		System.out.println("Drawing Rectangle");
	}
}

class Circle extends Shape
{
	void draw()
	{
		System.out.println("Drawing Circle");
	}
}

public class AbstractClassRealTime {

	public static void main(String[] args) {
		
		Shape ref=new Rectangle();
		ref.draw();
		
		Shape ref1=new Circle();
		ref1.draw();

	}

}
