package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

public class MyTest2 {

	public static void main(String[] args) {
		
		
	String str="sample ! test & and new sample test* kind of sample kind (";
	str=str.replaceAll("[^a-zA-Z0-9]", " ");
	str=str.replaceAll("  ", " ");
	str=str.replaceAll("   ", " ");
	str=str.replaceAll("    ", " ");
	System.out.println(str);
	String []s1=str.split(" ");
	TreeMap<String,Integer> mp=new TreeMap<String,Integer>();
	
	for(String x:s1)
	{
		if(mp.containsKey(x))
		{
			mp.put(x,(mp.get(x)+1));
		}
		else
		{
			mp.put(x, 1);
		}
	}
	
	for(Map.Entry entry:mp.descendingMap().entrySet())
	{
		System.out.println(entry.getKey());
		System.out.println(entry.getValue());
	}
	
	
	
	
	List<Integer> li=new ArrayList<Integer>();
	for(Map.Entry y:mp.entrySet())
	{
		li.add((Integer) y.getValue());
	}
	
	
	System.out.println("Elements of list are "+li);
	
	List<String> li2=new ArrayList<String>();
	for(Map.Entry z:mp.entrySet())
	{
		li2.add((String) z.getKey());
	}
	
	Collections.reverse(li2);
	System.out.println("Elements of list are "+li2);
	

	
	
	
	
	
	

	}

}
