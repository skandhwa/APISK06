package AbstractionConcepts;

import java.util.TreeSet;

public class MapPrograms {

	public static void main(String[] args) {
	
		String str="sample! test were made sample * ! these test were made easy & and were& new and sample";
		
		
		
		String str1= str.replaceAll("[^a-zA-Z0-9]", " ");  
		
		System.out.println(str1);
		
		str1=str1.replaceAll("  ", " ");
		
		
		
		System.out.println(str1);
		
		String []s2=str1.split(" ");
		
		TreeSet<String> s1=new TreeSet<String>();
		
		for(String x:s2)
		{
			System.out.println(x);
		}
		
		
		
	
		
		

	}

}
