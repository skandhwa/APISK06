package AbstractionConcepts;

public class StringReplacementEx {

	public static void main(String[] args) {
		
		String str="tomorrow";
		char []ch=str.toCharArray();
		char toreplace='o';
		String replacement ="$";
		StringBuilder sb=new StringBuilder();
		int count=3;
		
		
		
		for(char x:ch)
		{
			if(x==toreplace)
			{
			   sb.append(replacement.repeat(count));
			   count--;
			}
			else
			{
				sb.append(x);
			}
		}
		
		System.out.println(sb.toString());
		
		
		
		
		

	}

}
