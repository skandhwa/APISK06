package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ValueLasCode {

	public static void main(String[] args) {
		 String str="Saurabh Kandhway";
		 str=str.toLowerCase();
	      List<String> li=new ArrayList<String>();
	      List<String> li2=new ArrayList<String>();
	      
	      
	      String []s=str.split(" ");
	      
	      System.out.println(s[0]);
	      System.out.println(s[1]);
	      
	      
	   char []ch1=  s[0].toCharArray();
	    char []ch2= s[1].toCharArray();
	    
	    System.out.println(Arrays.toString(ch1));
	    System.out.println(Arrays.toString(ch2));
	    
	    Arrays.sort(ch1);
	    Arrays.sort(ch2);
	    
//	    System.out.print(Arrays.toString(ch1)+"  ");
//	    System.out.println(Arrays.toString(ch2)); 
	    
	    for(Character x:ch1)
	    {
	    	System.out.print(x);
	    }
	    
	    System.out.print(" ");
	    
	    for(Character y:ch2)
	    {
	    	System.out.print(y);
	    }
	    
	    

	}

}
