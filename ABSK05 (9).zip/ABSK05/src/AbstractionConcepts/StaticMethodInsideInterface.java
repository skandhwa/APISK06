package AbstractionConcepts;

interface H2
{
	void draw();
	static int add(int x,int y)
	{
		return x+y;
	}
	
}

class H3 implements H2
{
	public void draw()
	{
		System.out.println("Draw method");
	}
	
}
public class StaticMethodInsideInterface {

	public static void main(String[] args) {
		
	System.out.println(H2.add(45, 67));	
	
	H2 ref=new H3();
	ref.draw();
	
	
	
		

	}

}
