package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Collections;

public class MoveAllElementtoRightSide {

	public static void main(String[] args) {
		
		int []a= {2,-9,5,-8,-5,6,-11};
		
		ArrayList<Integer> li1=new ArrayList<Integer>();
		ArrayList<Integer> li2=new ArrayList<Integer>();
		
		
		for(int x:a)
		{
			if(x>0)
			{
				li1.add(x);
			}
			else
			{
				li2.add(x);
				Collections.sort(li2);
				Collections.reverse(li2);
			}
		}
		
		li1.addAll(li2);
		
		System.out.println(li1);
		
		

	}

}
