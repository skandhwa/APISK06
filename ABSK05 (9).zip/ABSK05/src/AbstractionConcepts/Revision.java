package AbstractionConcepts;


interface YU 
{
	void display();
	void test();
	
}

interface YZ extends YU
{
	void message();
}

class UT implements YU,YZ
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	public void test()
	{
		System.out.println("Hello test");
	}
	
	public void message()
	{
		System.out.println("Hello message");
	}
}


class UY extends UT
{
	
}






public class Revision {

	public static void main(String[] args) {
		
		UY obj=new UY();
		obj.display();
		obj.test();
		
		
		

	}

}
