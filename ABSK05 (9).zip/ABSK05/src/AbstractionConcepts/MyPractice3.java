package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyPractice3 {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("Hi");
		li.add("This is ");
		li.add("Saurabh");
		li.add("Welcome");
		li.spliterator();
		
		for(String x:li)
		{
			System.out.println(x);
			
			li.spl
		}
		
	//	li.spliterator();
		
		
//		for(String x:li)
//		{
//			System.out.println(x);
//		}
//		
//		Object[]a=li.toArray();
		
	int y=	li.size();
		
		System.out.println(y);
		
		for(String x:li)
		{
			System.out.println(x);
		}
		
		Object[]a=li.toArray();
		
		System.out.println(a.toString());
		
		
		li.set(2, "Welcome");
		
		
		
		ArrayList words = new ArrayList<>(Arrays.asList(“hello”, “world”, “foo”, “bar”));

		ArrayList list1 = new ArrayList<>(words.split(2)); // split into two parts with 2 elements in each part

		ArrayList list2 = new ArrayList<>(words.split(2, 2)); 
		
		
		
		
		
		
		
		
		
		
		

	}

}
