package AbstractionConcepts;

public class MMTEx {

	public static void main(String[] args) {
		
		
		
		

	}

}
