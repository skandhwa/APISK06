package AbstractionConcepts;

public class PrimeNumberSeries {

	public static void main(String[] args) {
		
		int n=20;
		int m=0;
		int flag=0;
		
		m=n/2;
		
		
		for(int k=0;k<100;k++)
		{
		
		if(k==0 || k==1)
		{
			System.out.println("Not a prime number");
		}
		
		else
		{
			for(int i=2;i<=m;i++)
			{
				if(k%i==0)
				{
					System.out.println("not a prime number");
					 flag=1;
					break;
					
				}
			}
				if(flag==0)
					{
						System.out.println("Primee number");
					}
				}
				
				
			}
		
		
	}
		
		
		
	}
	
	
