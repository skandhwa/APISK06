package AbstractionConcepts;


interface I3
{
	void display();
	default  void test()
	{
		System.out.println("How are you");
		
		
	}
}






class H4 implements I3
{
public void display() 
	{
		System.out.println("Hello");
		
	}
	
}

public class DefaultMethodinInterface {

	public static void main(String[] args) {
		
		I3 ref=new H4();
		ref.display();
		ref.test();
		

	}

}
