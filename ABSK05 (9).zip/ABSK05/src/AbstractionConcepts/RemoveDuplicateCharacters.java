package AbstractionConcepts;

import java.util.HashSet;

public class RemoveDuplicateCharacters {

	public static void main(String[] args) {
		
		int []a= {1,2,3,2,4,3,5,2,3};
		String str=a.toString();
		
		HashSet<String> s1=new HashSet<String>();
		
		for(int i=0;i<str.length();i++)
		{
			
		
		
			
			
		}
		
		
		

	}

}
