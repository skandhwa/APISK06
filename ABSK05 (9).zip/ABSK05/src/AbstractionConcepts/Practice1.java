package AbstractionConcepts;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

public class Practice1 {
//	
//	public static Properties getProperty() throws IOException
//	{
//		FileInputStream fs=new FileInputStream("src\\AbstractionConcepts\\Test.Properties");
//		Properties prop=new Properties();
//		prop.load(fs);
//		return prop;
//		
//		
//	}
//	
	
	

	public static void main(String[] args) throws IOException {
		
//		System.out.println(Practice1.getProperty());
		
		String str="Saurabh";
		
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();
		char []ch=str.toCharArray();
		
		for(char x:ch)
		{
			if(mp.containsKey(x))
			{
				mp.put(x, (mp.get(x)+1));
			}
			
			else
			{
				mp.put(x,1);
			}
		}
		
		for(Map.Entry y:mp.entrySet())
		{
			System.out.print(y.getKey());
			System.out.println(y.getValue());
		}
		
		
		
		
		
		
	

	}

}
