package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MoveAllZeroRightSide {

	public static void main(String[] args) {
		
		int []a= {2,-3,-6,4,-8,9,-9,8,-11};
		
		List<Integer> li=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		for(Integer x:a)
		{
			if(x<0)
			{
				li.add(x);
				Collections.sort(li);
				Collections.reverse(li);
			}
			
			else
			{
				li2.add(x);
				Collections.sort(li2);
				Collections.reverse(li2);
			}
		}
		
		li.addAll(li2);
		
		Object[] b=li.toArray();
		
		for(Object y:b)
		{
			System.out.print(y+" ");
		}
		
		
		
		
		
		
		
		

	}

}
