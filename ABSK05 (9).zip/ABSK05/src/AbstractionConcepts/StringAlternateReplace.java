package AbstractionConcepts;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class StringAlternateReplace {

	public static void main(String[] args) {
		
		String str="Tomorrow";
		char []ch=str.toCharArray();
		
		Set<Character> s1=new HashSet<Character>();
		
		for(Character x:ch)
		{
			s1.add(x);
		}
		
		System.out.println(s1);
		
		
	String str2=s1.toString();
	
	System.out.println(str2);
	
	char []ch2=str2.toCharArray();
	
	System.out.println(Arrays.toString(ch2));
	
	StringBuilder sb=new StringBuilder();
	
	for(Character x:s1)
	{
		sb.append(x);
	}
	
	System.out.println(sb);
		
			
			
		
		
		
		
		

	}

}
