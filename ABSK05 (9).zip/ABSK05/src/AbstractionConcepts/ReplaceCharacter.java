package AbstractionConcepts;

public class ReplaceCharacter {
    public static void main(String[] args) {
        String input = "Tomorrow";
        char charToReplace = 'o'; // Character to replace
        String replacement = "&"; // Replacement character
        
        StringBuilder output = new StringBuilder();
        int count = 1; // To track the number of '&' to append
        
        // Iterate through the input string
        for (char c : input.toCharArray()) {
            if (c == charToReplace) {
                // Replace 'o' with increasing number of '&'
                output.append(replacement.repeat(count));
                count++; // Increment count for next occurrence
            } else {
                output.append(c); // Append the character if it's not 'o'
            }
        }
        
        // Print the output
        System.out.println("Input: " + input);
        System.out.println("Output: " + output.toString());
    }
}
