package AbstractionConcepts;

import java.util.HashSet;

public class RemoveRepeatCharacters {

	public static void main(String[] args) {
		
		String str="Tomorrow";
		char []ch=str.toCharArray();
		StringBuilder sb=new StringBuilder();
		
		HashSet<Character> s1=new HashSet<Character>();
		
		
		for(char x:ch)
		{
			if(s1.contains(x))
			{
				sb.append('$');
			}
			
			else
			{
				s1.add(x);
				sb.append(x);
			}
		}
		
		System.out.println(sb.toString());
		
		
		
		
		
		
	
		
		
			
			
		}
		
		
		
		

	}


