package AbstractionConcepts;

import java.util.HashMap;
import java.util.Map;

public class OccurenceofCharacter {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		String str1=str.replace("a", "$");
		System.out.println("The replced value is "+str1);
		
		
		
		
		
		Map<Character,Integer> mp=new HashMap<Character,Integer>();
		
		char []strArray=str.toCharArray();
		
		for(char c:strArray)
		{
			if(mp.containsKey(c))
			{
				mp.put(c, (mp.get(c)+1));
			}
			else
			{
				mp.put(c, 1);
			}
		}
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey());
			System.out.println(x.getValue());
		}
		
		
		
		

	}

}
