package AbstractionConcepts;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MyPractice1 {

	public static void main(String[] args) {
		
		String str="My name is Saurabh and I am an Automation eng";
		String temp;

		str=str.toLowerCase();
		
		String []s=str.split(" ");
		
		
		for(int i=0;i<s.length;i++)
		{
			for(int j=i+1;j<s.length;j++)
			{
				if(s[i].length()<s[j].length())
				{
					temp=s[i];
					s[i]=s[j];
					s[j]=temp;
				}
			}
			
			System.out.print(s[i]+" ");
		}
		
		
		

//		StringBuilder sentence=new StringBuilder();
//
//		String []s1=str.split(" ");
//
//		for(String x:s1)
//		{
//			
//		List<Character> li=new ArrayList<Character>();
//		for(char y:x.toCharArray())
//		{
//		
//			
//		li.add(y);
//		int k=li.size();
//		
//
//		}
//
//		Collections.sort(li);
//		
//		
//		
//
//		StringBuilder word=new StringBuilder();
//		for(char z:li)
//		{
//		
//		word.append(z);
//
//		}
//
//		
//		sentence=sentence.append(word).append(" ");
//
//
//		}
//
//     System.out.println(sentence.toString());

	}
	
	
	
}

	

		


