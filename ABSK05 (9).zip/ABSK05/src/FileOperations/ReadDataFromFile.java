package FileOperations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ReadDataFromFile {

	public static void main(String[] args) throws FileNotFoundException  {
		
		
		
		
		File obj=new File("D:\\03rdOctoberFileNew\\test1234.txt");
		
		//BufferedReader br=new BufferedReader(obj);
		Scanner sc=new Scanner(obj);
		while(sc.hasNextLine())
		{
			String filecontent=sc.nextLine();
			System.out.println(filecontent);
		}
		
		sc.close();
		
		
		
		
//		File obj=new File("‪D:\\03rdOctoberFileNew\\test1234.txt");
//		
//		try
//		{
//		Scanner datareader=new Scanner(obj);
//		
//		while(datareader.hasNextLine())
//		{
//			String filedata=datareader.nextLine();
//			System.out.println(filedata);
//			
//		}
//		
//		datareader.close();
//		}
//		
//		catch(Exception e)
//		{
//			System.out.println("caught with "+e);
//		}
//		
//		
		

	}

}
