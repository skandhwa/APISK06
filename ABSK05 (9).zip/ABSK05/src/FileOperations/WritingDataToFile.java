package FileOperations;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class WritingDataToFile {

	public static void main(String[] args) throws IOException {
		
		File obj=new File("E:FirstName9.txt");
		
		boolean flag=	obj.createNewFile();
		System.out.println(flag);
		
//		FileWriter fw=new FileWriter("‪‪D:FirstName9.txt");
//		fw.write("Java is a robust language");
//		fw.close();
//		System.out.println("The content is written successfully");
		
		FileWriter f1=new FileWriter("D:\\03rdOctoberFileNew\\test177.txt");
		File f=new File("D:\\03rdOctoberFileNew\\test167.txt");
		
		
		f1.append('d');
		f1.append("testn");
		
	
		f1.write("Java is a robust language and structured");
        f1.close();
        System.out.println("Content added to file");
        
    long y=    f.length();
    System.out.println(y);
		
		
		
		
		

	}

}
