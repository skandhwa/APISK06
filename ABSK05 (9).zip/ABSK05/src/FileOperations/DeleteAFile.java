package FileOperations;

import java.io.File;

public class DeleteAFile {

	public static void main(String[] args) {
		
		
		File obj=new File("E:\\DataFiles\\Test123.txt");
	boolean flag=	 obj.delete();
	System.out.println(flag);
	
	if(flag==true)
	{
		System.out.println("file deleted successfully");
	}
	else
	{
		System.out.println("File is not deleted");
	}

	}

}
