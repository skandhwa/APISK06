package FileOperations;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {

	public static void main(String[] args) throws IOException {
		
		File obj=new File("D:\\Test22ndJune\\Test7.txt");
		
	boolean x=	obj.createNewFile();
	
	System.out.println(x);
	
//	if(flag==true)
//	{
//		System.out.println(obj.getName());
//		System.out.println(obj.getAbsolutePath());
//		
//	System.out.println("Is Readable  "+obj.canRead());	
//	System.out.println("Is Writable  "+obj.canWrite());	
//	System.out.println("The length is "+obj.length());	
		
	//}
	
	
		
		

	}
	
}


