package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListCloneMethod {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(34);
		li.add(67);
		li.add("Saurabh");
		li.add(true);
		li.add('A');
		li.add(24.56f);
		
	boolean flag=	li.contains(687);
	
	System.out.println(flag);
	
	
	Object x=li.get(3);
	System.out.println(x);
	
	
	int y=li.indexOf("Saurabh");
	System.out.println("index is "+y);
	
	
		
	
	}

}
