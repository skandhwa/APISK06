package CollectionsInterface;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class LinkedListExample {

	public static void main(String[] args) {
		
		
		LinkedList<Object> li=new LinkedList<Object>();
		
		li.add(1234);
		li.add("C#");
		li.add(false);
		li.add('A');
		li.add(34.67f);
		
		ListIterator<Object> itr=li.listIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		System.out.println("Printing in reverse direction");
		while(itr.hasPrevious())
		{
			System.out.println(itr.previous());
		}

	}

}
