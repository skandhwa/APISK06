package CollectionsInterface;

import java.util.ArrayList;

public class ArrayListRetailAll {

	public static void main(String[] args) {
		
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("python");
		li.add("java");
		li.add("html");
		li.add("css");
		
		
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("C#");
		li2.add("Angular");
		li2.add("python");
		li2.add("css");
		li2.add("java");
		li2.add("Azure");
		
		
		li2.retainAll(li);
		
		for(String x:li2)
		{
			System.out.println(x);
		}
		
		

	}

}
