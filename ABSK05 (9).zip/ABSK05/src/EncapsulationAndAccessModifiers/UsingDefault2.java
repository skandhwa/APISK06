package EncapsulationAndAccessModifiers;

public class UsingDefault2 {

	public static void main(String[] args) {
		
		AM3 obj=new AM3();
		obj.display();
		
		Am4 obj1=new Am4();
		obj1.display();
		

	}

}
