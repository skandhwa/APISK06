package EncapsulationAndAccessModifiers;

class AM3
{
	void display()
	{
		System.out.println("Hello How r u");
	}
}

class Am4 extends AM3
{
	void test()
	{
		display();
	}
}


public class UsingDefaultAM {

	public static void main(String[] args) {
		
		
		
		

	}

}
