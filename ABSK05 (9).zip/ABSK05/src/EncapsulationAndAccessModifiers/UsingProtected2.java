package EncapsulationAndAccessModifiers;

public class UsingProtected2 {

	public static void main(String[] args) {
		
		UsingProtected1 obj=new UsingProtected1();
		obj.test1();

	}

}
