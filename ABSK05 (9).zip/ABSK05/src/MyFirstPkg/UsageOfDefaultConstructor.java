package MyFirstPkg;

class B1
{
	
	
	int x;
	float p;
	char ch;



void display()
{
	System.out.println(x);
	System.out.println(p);
	System.out.println(ch);
}

}



public class UsageOfDefaultConstructor {

	public static void main(String[] args) {
		
		B1 obj=new B1();
		obj.display();
		

	}
}



