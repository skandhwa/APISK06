package MyFirstPkg;

class B
{
	void display(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
	
	int sum(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
		return c;
	}
	
	float multiply(int p,int q)
	{
		float z=p*q;
		System.out.println(z);
		return z;
	}
	
	
}

public class MethodWithReturnTypeSecond {
	
	double divide(float m,float n)
	{
		double g=m/n;
		System.out.println(g);
		return g;
	}
	
	
	

	public static void main(String[] args) {
		
		B obj=new B();
		obj.display(34, 56);
	System.out.println(obj.sum(28,95));	
	obj.multiply(12, 32);
	
	
	MethodWithReturnTypeSecond obj1=new MethodWithReturnTypeSecond();
	obj1.divide(45, 5);
	
	
		
		
		
		
		

	}

}
