package MyFirstPkg;

public class TernaryOperator {

	public static void main(String[] args) {
		
		
//		int a=20;
//		int b=40;
//		
//		int max;
//		max=(a>b)?a:b;
//		System.out.println(max);
		
		
		int a=4000;
		int b=500;
		int c=70;
		int d=550;
		
		int max;
		
		max=(a>b)?(a>c?a:c):(b>c?b:c);
		
		//max=(a>b)?(a>c?((a>d)?a:d):(c>d?c:d))
		
		System.out.println("The maximum number is " +max);
		
		

	}

}
