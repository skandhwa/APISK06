package MyFirstPkg;

class C
{
	String display()
	{
         String str="Saurabh";
         System.out.println(str);
         return str;
	}
	
	double test(float p,float q)
	{
		return p/q;
	}
	
	
}



public class MethodReturnTypeExample {

	public static void main(String[] args) {
		
		C obj=new C();
		obj.display();
		
	System.out.println(obj.test(24, 6));	
		
		

	}

}
