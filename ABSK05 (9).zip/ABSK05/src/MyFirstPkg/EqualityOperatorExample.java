package MyFirstPkg;

public class EqualityOperatorExample {

	public static void main(String[] args) {
		
		int x=10*2*4;///Assignment of values and process is called initialization
		int y=20;
		
		if(x!=y)///80!=20
		{
			System.out.println("pass");
		}
		
	//	>,<,>=,<=,==
		
		int p=20;
		int q=30;
		int r=40;
		
		int z=p*2;
		
		System.out.println(z>=p && r<p );
		
		
		
		
		

	}

}
