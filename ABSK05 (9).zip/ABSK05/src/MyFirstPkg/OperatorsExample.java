package MyFirstPkg;

public class OperatorsExample {

	public static void main(String[] args) {
		
		
//		int c=5;
//		
//		int d=10;
//		
//		 
//		int b= --d + c++ +  ++d  - --c;
//		 
//		/// 9 + 5  + 10 - (--6)
//		
//		//9 +5+10-5
//		
//		//// 5 + (++4)//5+5
//		
//		
//		System.out.println(b);
		
		
		
		
//		int x=10;
//		int y=5;
//		int z= 7;
//		
//	int r= ++x + --z + y++ - --y + x++;//28,24,30
//	
//	//11+6+5 - (--6) + 11
//	//11+6+5-5+11
//	
//	
//	///////x=11,z=6
//	
//	System.out.println(r);
//		
		
		int p=29;
		System.out.println(~p);
		
		
		
		
		

	}

}
