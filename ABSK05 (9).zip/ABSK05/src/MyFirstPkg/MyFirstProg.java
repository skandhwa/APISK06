package MyFirstPkg;

public class MyFirstProg {


	public static void main(String[] args) 
	{
		
		System.out.println("Hello");
		System.out.println("Saurabh");
		System.out.print("How are you");
		
		
		

	}

}
