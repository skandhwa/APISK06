package MyFirstPkg;

public class ShiftOperator {

	public static void main(String[] args) {
		
		//System.out.println(20<<4);////
		
		
		System.out.println(800>>6);//800/64

	}

}
