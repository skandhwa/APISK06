package MyFirstPkg;

class A1
{
	
	int a,b;
	A1()
	{
		System.out.println("Hello I am constructor");
		///int a=10;
		//float b=20;
//		System.out.println(a);
//		System.out.println(b);
	}
	
	
	
	
	
	
	
	void display()
	{
		System.out.println("a and b are"+a+" "+b);
	}
}

public class DefaultConstructorEx {

	public static void main(String[] args) {
		
		A1 obj=new A1();
		obj.display();
		
		
		

	}

}
