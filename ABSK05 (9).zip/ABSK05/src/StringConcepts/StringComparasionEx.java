package StringConcepts;

public class StringComparasionEx {

	public static void main(String[] args) {
		
		String str="Gaurabh";
		String str1="Saurabh";
		
		System.out.println(str==str1);
		
		System.out.println(str.equals(str1));
		
		System.out.println(str.compareTo(str1));

	}

}
