package StringConcepts;

public class SwapTwoStringwithoutUsingThirdvariable {

	public static void main(String[] args) {
		
		String str="Good";
		String str1="Bad";
		
		System.out.println("Before Swapping values are "+str+"  "+str1 );
		
		str=str+str1;
		
	str1=	str.substring(0, (str.length()-str1.length()));
	
	str=str.substring(str1.length());//str.substring(4)
	
	System.out.println("After Swapping values are "+str+"  "+str1 );
		
		
		

	}

}
