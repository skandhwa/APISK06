package StringConcepts;

public class StringMethods7 {

	public static void main(String[] args) {
		
//		String str="InDIA";
//		
//	String str1=	str.toLowerCase();
//	System.out.println(str1);
	
	String str="indIA";
	
	String str1=	str.toUpperCase();
	System.out.println(str1);
	
	String str2="     Selenium            ";
	System.out.println(str2);
	
	str2=str2.trim();
	System.out.println(str2);
	
	int x=40;
	String s1=String.valueOf(40);
	
	//String s="India";
	System.out.println(s1+10);
	
	
		

	}

}
