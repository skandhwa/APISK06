package StringConcepts;

import java.util.Scanner;

public class StringAssignmentNew {

	public static void main(String[] args) {
	
		
		Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the name");
		   String name;
		   name=sc.nextLine();
		   
		String[]arr=   name.split(" ");
		
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		
	String str1=	arr[1].toString();
	System.out.println(str1);
	
String str2=	str1.substring(5);
System.out.println(str2);
	String str3=str2.toUpperCase();
	
	int x=str3.length();
	System.out.println(x);
	
		
		
		

	}

}
