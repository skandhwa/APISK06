package StringConcepts;

import java.util.Arrays;

public class StringProgramAnagram {

	public static void main(String[] args) {
		
		String str="Brag";///abgr
		String str1="Grab";//abgr
		
	str=str.toLowerCase();
	str1=str1.toLowerCase();
	
	if(str.length()!=str1.length())
	{
	System.out.println("Strings are not anagram because length are not equal");
    }
	
	else
	{
	char []ch=	str.toCharArray();
	char []ch1=	str1.toCharArray();
	Arrays.sort(ch);
	Arrays.sort(ch1);
	
	if(Arrays.equals(ch, ch1)==true)
	{
		System.out.println("Both String are Anagram");
	}
	else
	{
		System.out.println("Both Strings are not Anagram");
	}
	
	
	
	}

}
	
}
