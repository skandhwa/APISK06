package StringConcepts;

public class StringBufferExample {

	public static void main(String[] args) {
		
		String str2=new String ("Bjp");
		str2.concat("Won");
		System.out.println(str2);
		
		StringBuffer obj=new StringBuffer("Hello");
		
		obj.append("Saurabh");
		System.out.println(obj);
		

	}

}
