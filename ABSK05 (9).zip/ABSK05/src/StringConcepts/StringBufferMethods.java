package StringConcepts;

public class StringBufferMethods {

	public static void main(String[] args) {
		
		StringBuffer str=new StringBuffer("Hello");
//		str.insert(2,"Saurabh");
//		System.out.println(str);
		
		
		str.replace(1, 3, "Saurabh");
		System.out.println(str);
		

	}

}
