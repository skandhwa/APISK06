package PolyMorphism;


class E3
{
	void test(float z,float x)
	{
		System.out.println("Hello User");
	}
	
	void test(float z,float x,int h)
	{
		System.out.println("Hello");
	}
}




public class FirstExample {

	public static void main(String[] args) {
		
		
		
		

	}

}
