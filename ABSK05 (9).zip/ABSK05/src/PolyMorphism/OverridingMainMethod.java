package PolyMorphism;

class H6
{
	public static void main()
	{
		System.out.println("Hello");
	}

}

class H7 extends H6
{
	public static void main()
	{
		System.out.println("Hello User");
	}
}




public class OverridingMainMethod extends H6 {
	

	public static void main(String[] args) {
		
		H7.main();
		H6.main();
		
		
		
		
		

	}

}
