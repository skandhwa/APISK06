package PolyMorphism;

class F6
{
	 int add(int x,int y)
	{
		return x+y;
	}
	
}
class F7 extends F6
{
	
	 int add(int x,int y)
	{
		return x+y;
	}
	
}
public class RunTimePolymorphism {

	public static void main(String[] args) {
		
		F6 obj=new F6();
	System.out.println(obj.add(34,56));	
		
	
	F7 obj1=new F7();
	System.out.println(obj1.add(324,546));	
		
		
		
		
		
		

	}

}
