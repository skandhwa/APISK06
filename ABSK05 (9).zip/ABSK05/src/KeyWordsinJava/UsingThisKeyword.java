package KeyWordsinJava;

class M2
{
	String name;
	int id;
	float salary;
	
	
	M2(String name,int id,float salary)
	{
		this.name=name;
		this.id=id;
		this.salary=salary;
	}
	
	
	void display()
	{
		System.out.println(name+"  "+id+" "+salary);
	}
	
}


class M3 extends M2
{
	String course;
	M3(String name,int id,float salary,String course)
	{
		super(name,id,salary);
		this.course=course;
	}
	
	void display1()
	{
		System.out.println(name+"  "+id+" "+salary+" "+course);
	}
	
}


public class UsingThisKeyword {

	public static void main(String[] args) {
		
		M2 obj=new M2("Mark",3456,60000f);
		obj.display();
		
		M3 obj1=new M3("Tom",9876,8000f,"Java");
		obj1.display1();
		
		

	}

}
