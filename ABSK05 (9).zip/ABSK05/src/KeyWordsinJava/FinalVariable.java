package KeyWordsinJava;

public class FinalVariable {
	
	final static float pi=3.14f;
	
	void display()
	{
		//pi=4.15f;
		System.out.println("The value of pi is "+pi);
	}
	
	

	public static void main(String[] args) {
		
		FinalVariable obj=new FinalVariable();
		obj.display();
		
		

	}

}
