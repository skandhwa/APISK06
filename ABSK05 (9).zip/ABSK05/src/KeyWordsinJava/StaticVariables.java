package KeyWordsinJava;

class Emp6
{
	int empid;
	String empname;
	static String companyname="Infosys";
	//String companyname;
	
	Emp6(int empid,String empname)
	{
		this.empid=empid;
		this.empname=empname;
		//this.companyname=companyname;
		
	}
	
	 void display()
	{
		System.out.println(empid+" "+empname+" "+companyname);
	}
	
}

public class StaticVariables {

	public  static void main(String[] args) {
		
		Emp6 obj=new Emp6(1234,"Tom");
		Emp6 obj1=new Emp6(4567,"Mark");
		Emp6 obj2=new Emp6(8976,"Henry");
		obj.display();
		obj1.display();
		obj2.display();
		//return 5;
		
		

	}

}
