package KeyWordsinJava;

class Student
{
	int roll;
	String name,course;
	float fees;
	int room;
	
	Student(int roll,String name,String course)
	{
		this.roll=roll;
		this.name=name;
		this.course=course;
	}
	
	Student(int roll,String name,String course,float fees)
	{
		this(roll,name,course);
		this.fees=fees;
//		this.roll=roll;
//		this.name=name;
//		this.course=course;
		
		
		
		
	}
	
	Student(int roll,String name,String course,float fees,int room)
	{
		this(roll,name,course,fees);
		this.room=room;
//		this.roll=roll;
//		this.name=name;
//		this.course=course;
		
		
		
		
	}
	
	
	
	
	void display()
	{
		System.out.println(roll+" "+name+" "+course+" "+fees);
	}
	
}
public class RealUsageofThis {

	public static void main(String[] args) {
		
		Student obj=new Student(1234,"Mark","Java");
		obj.display();
		Student obj1=new Student(1234,"Mark","Java",5000.0f);
		obj1.display();
		
		
		

	}

}
