package KeyWordsinJava;


class Volume
{
	final static float pi=3.14f;
	
	float volume;
	
	static final float cyllinder(int r,int h)
	{
		return pi*r*r*h;
	}
	
	static final double cone(int r,int h)
	{
		return (0.33*(pi*r*r*h));
	}
	
}
public class FinalAndStaticExample {
	public static void main(String[] args) {
		
	System.out.println(Volume.cyllinder(20,10));
	System.out.println(Volume.cone(30,8));
		

	}

}
