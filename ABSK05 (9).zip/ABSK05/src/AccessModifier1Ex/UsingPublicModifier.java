package AccessModifier1Ex;

public class UsingPublicModifier {
	
	public void display()
	{
		System.out.println("Hello Saurabh how r u");
	}
	

	public static void main(String[] args) {
		
		UsingPublicModifier obj=new UsingPublicModifier();
		obj.display();
		
		
	}

}
