package LoopingConcepts;

public class ifLoopExample {

	public static void main(String[] args) {
		
		int x=20;
		int y=20/2;
		
		if(x==y)///10==10
		{
			System.out.println("x and y are equal to each other");
		}
		
		System.out.println("We are quitting the code");
		
		
		
		
		

	}

}
