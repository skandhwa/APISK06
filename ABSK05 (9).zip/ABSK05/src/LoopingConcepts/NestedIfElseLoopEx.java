package LoopingConcepts;

public class NestedIfElseLoopEx {
	
	public void largest(int a,int b,int c,int d,int e,int f)
	{
		if(a>b && a>c && a>d && a>e && a>f)
		{
			System.out.println("a is maximum");
		}
		
		else if(b>a && b>c && b>d && b>e && b>f)
		{
			System.out.println("b is maximum");
		}
		
		else if(c>a && c>b && c>d && c>e && c>f)
		{
			System.out.println("c is maximum");
		}
		
		else if(d>a && d>b && d>c && d>e && d>f)
		{
			System.out.println("d is maximum");
		}
		else if(e>a && e>b && e>c && e>d && e>f)
		{
			System.out.println("e is maximum");
		}
		else
		{
			System.out.println("f is maximum");
		}
		
		
		
	}
	
	public static void main(String[] args) {
		
		NestedIfElseLoopEx obj=new NestedIfElseLoopEx();
		obj.largest(340, 1200, 87, 146,6500);
		
	}

}
