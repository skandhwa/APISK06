package LoopingConcepts;

public class forLoopExamples {

	public static void main(String[] args) {
	
		
		for(int i=1;i<=10;i++)
		{
			
			if(i!=7)
			{
			System.out.println(i);
			}
			
			
		}
		

	}

}
