package LoopingConcepts;

public class NestedIfElseLoopExample {

	public static void main(String[] args) {
	
		int a=40;
		int b=30;
		int c=45;
		
		if(a>b)
			
		{
			if(a>c)
			{
				System.out.println("a is maximum");
			}
			
			else
			{
				System.out.println("c is maximum");
			}
			
		}
		else
		{
			if(b>c)
			{
				System.out.println("b is maximum");
			}
			else
			{
				System.out.println("c is maximum");
			}
		}
		
		
		
		
	}

}
