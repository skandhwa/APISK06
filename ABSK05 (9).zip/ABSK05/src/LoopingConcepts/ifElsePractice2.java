package LoopingConcepts;

public class ifElsePractice2 {

	public static void main(String[] args) {
		
		int x=33;
		
		if(x%2==0)
		{
		
			System.out.println("Even Number");
		}
			
		
		else
		{
			
			System.out.println("Odd Number");
		}
		
		
		
		
		
		
		
		System.out.println("We are quitting the code");

	}

}
