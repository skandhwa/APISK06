package LoopingConcepts;

public class FactorialProgram {
	
	int factorial(int n)
	{
		if(n==0)
		{
			return 1;
		}
		
		else
		{
			return (n*factorial(n-1));//return(3*factoral(2))
		}
	}
	
	public static void main(String[] args) {
		
		FactorialProgram obj=new FactorialProgram();
		int i,n=5;
		
		int fact=obj.factorial(n);///obj.factorial(3)
		System.out.println(fact);
		
		
		
		

	}

}
