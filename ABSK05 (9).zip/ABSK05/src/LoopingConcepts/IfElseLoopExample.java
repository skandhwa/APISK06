package LoopingConcepts;

public class IfElseLoopExample {

	public static void main(String[] args) {
		
		int a=10*2;
		int b=30;
		
		
		if(a>=b)//30>=30
		{
			System.out.println("a is equal or max to b");
		}
		
		else
		{
			System.out.println("b is max");
		}
		
		
		

	}

}
