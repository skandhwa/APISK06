package LoopingConcepts;

public class ReverseofNumber {

	public static void main(String[] args) {
		
		int num=121;
		int x=num;
		
		int rev=0;
		
		while(num!=0)///67!=0//6!=0
		{
			int rem=num%10;///rem=675%10=5///67%10=7///rem=6%10=6
			
		rev=	rev*10+rem;///rev=0*10+em=0+5=5///rev=5*10+7=57//57*10+6=576
		num=num/10;///num=675/10=67///num=num/10=67/10=6//num=6/10=0
		
			
		}
		
		System.out.println("The reverse of number is "+rev);
		if(x==rev)
		{
			System.out.println("The number is palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}
		
		
		

	}

}
