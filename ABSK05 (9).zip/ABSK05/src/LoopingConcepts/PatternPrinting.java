package LoopingConcepts;

public class PatternPrinting {

	public static void main(String[] args) {
		
		int n=15;
		
		for(int i=0;i<n;i++)//i=0,0<3//i=1,1<3
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("*");//
			}
			
			System.out.println();
		}
		
		
		
		
		
		

	}

}
