package LoopingConcepts;

public class NestedIfLoop {

	public static void main(String[] args) {
		
		int age=23;
		int poll=1;
		String city="Kolkata";
		
		
		if(age>18)//23>18
		{
			if(poll==2)//true
			{
				if(city=="Kolkata")///true
				{
					System.out.println("You are elligible to vote");
				}
			}
		}
		
		
		System.out.println("We are quitting the code");
		
		
		

	}

}
