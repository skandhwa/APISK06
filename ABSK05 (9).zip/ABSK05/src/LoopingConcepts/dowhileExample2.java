package LoopingConcepts;

public class dowhileExample2 {

	public static void main(String[] args) {
		
		int x=5;
		int sum=0;
		
		do
		{
			sum+=x;
			x--;
		}
		
		while(x!=0);//
		
		System.out.println(sum);
		
		

	}

}
