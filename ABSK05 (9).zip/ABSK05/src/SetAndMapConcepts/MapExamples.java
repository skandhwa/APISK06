package SetAndMapConcepts;

import java.util.HashMap;
import java.util.Map;

public class MapExamples {

	public static void main(String[] args) {
		
		Map<Integer,String>mp=new HashMap<Integer,String>();
		mp.put(23,"Rohan");
		mp.put(34, "Mohan");
		mp.put(23,"Harsh");
		mp.put(54, "Rohit");
		
		//System.out.println(mp);
		
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
			
			
		
		
		
		

	}

}
