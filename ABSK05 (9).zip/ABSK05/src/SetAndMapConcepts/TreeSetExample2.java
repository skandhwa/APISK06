package SetAndMapConcepts;

import java.util.TreeSet;

public class TreeSetExample2 {

	public static void main(String[] args) {
		
        TreeSet<Integer> s1=new TreeSet<Integer>();
		
		s1.add(34);
		s1.add(56);
		s1.add(67);
		s1.add(43);
		s1.add(12);
		s1.add(89);
		
	System.out.println(s1.pollFirst());	
		
	System.out.println(	s1.pollLast());
		
		
		
		

	}

}
