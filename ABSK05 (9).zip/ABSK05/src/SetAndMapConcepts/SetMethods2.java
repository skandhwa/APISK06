package SetAndMapConcepts;

import java.util.HashSet;
import java.util.Set;

public class SetMethods2 {

	public static void main(String[] args) {
		
		Set<Object> s1=new HashSet<Object>();
		s1.add(23);
		s1.add(13);
		s1.add(53);
		s1.add("Mango");
		s1.add("Orange");
		s1.add(true);
		s1.add('A');
		s1.add(34.56f);
		
	boolean flag=	s1.contains("melon");
	System.out.println(flag);
		
		
		
		

	}

}
