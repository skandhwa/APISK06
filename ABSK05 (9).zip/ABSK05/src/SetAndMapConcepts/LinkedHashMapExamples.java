package SetAndMapConcepts;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class LinkedHashMapExamples {

	public static void main(String[] args) {
		
		
		Map<Integer,String>mp=new LinkedHashMap<Integer,String>();
		mp.put(23,"Rohan");
		mp.put(34, "Mohan");
		mp.put(23,"Harsh");
		mp.put(54, "Rohit");
		
		mp.replace(54,"Harry");
		
		for(Map.Entry m:mp.entrySet())
		{
			System.out.print(m.getKey()+"  " );
			System.out.println(m.getValue());
		}
		

	}

}
