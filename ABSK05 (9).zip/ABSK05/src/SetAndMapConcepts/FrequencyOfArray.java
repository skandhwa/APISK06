package SetAndMapConcepts;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfArray {

	public static void main(String[] args) {
		
		int a[]= {10,20,20,30,10,20,30,20,20};
		
	int n=	a.length;
	
	Map<Integer,Integer> mp=new LinkedHashMap<Integer,Integer>();

	for(int i=0;i<n;i++)//i=0,0<8//i=1,1<8//i=2,2<8//i=3,3<8//i=4,4<8
	{
		if(mp.containsKey(a[i]))
		{
			mp.put(a[i], (mp.get((a[i])))+1);///mp.put(20,2)
			
			///mp.put(10,1+1)=mp.put(10,2)
		}
			else
		{
			mp.put(a[i],1);///mp.put(a[0],1)//mp.put(10,1)//mp.put(20,1)
		}
	}
	
	
	for(Map.Entry x:mp.entrySet())
	{
		System.out.print(x.getKey()+"  ");
		System.out.println(x.getValue());
		
		
		
		
		
	}
	
	
	int maxFrequency=0;
	int maxOccurringInteger =0;
	
	for (Map.Entry<Integer, Integer> entry : mp.entrySet()) {
        if (entry.getValue() > maxFrequency) {
            maxFrequency = entry.getValue();
            maxOccurringInteger = entry.getKey();
        }
    }
	
	  System.out.println("Maximum occurring character: '" + 
	  maxOccurringInteger + "' with a frequency of " + maxFrequency);
		
		

	}

}
