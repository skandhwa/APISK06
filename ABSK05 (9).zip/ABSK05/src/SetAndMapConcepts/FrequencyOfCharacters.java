package SetAndMapConcepts;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfCharacters {

	public static void main(String[] args) {
		String str="SSSSSaaaaaaaaurabh";
		Map<Character,Integer> mp=new LinkedHashMap<Character,Integer>();	
	char[]ch=	str.toCharArray();
	for(char x:ch)
	{
		if(mp.containsKey(x))
		{
			mp.put(x, (mp.get(x))+1);
		}
		
		else
		{
			mp.put(x,1);
		}
	}
		for(Map.Entry y:mp.entrySet())
	{
		System.out.print(y.getKey()+"  ");
		System.out.println(y.getValue());
	
	}
	int maxFrequency=0;
	char maxOccurringChar = ' ';
	
	for (Map.Entry<Character, Integer> entry : mp.entrySet()) {
        if (entry.getValue() > maxFrequency) {
            maxFrequency = entry.getValue();
            maxOccurringChar = entry.getKey();
        }
    }
	
	  System.out.println("Maximum occurring character: '" + maxOccurringChar + "' with a frequency of " + maxFrequency);
		
		
		

	}

}
