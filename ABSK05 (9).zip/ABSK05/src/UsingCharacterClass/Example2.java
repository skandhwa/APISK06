package UsingCharacterClass;

public class Example2 {

	public static void main(String[] args) {
		
		char ch=' ';
		char ch2='\n';
		char ch3='\t';
		;
		System.out.println(Character.isWhitespace(ch3));
		

	}

}
