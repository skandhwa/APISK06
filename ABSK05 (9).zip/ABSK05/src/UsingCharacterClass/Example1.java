package UsingCharacterClass;

public class Example1 {

	public static void main(String[] args) {
		
		
		//isLetter()
		
		
		char ch='@';
		
	boolean flag=	Character.isLetter(ch);
	System.out.println(flag);
	
	
	char ch2='a';
	boolean flag2=Character.isDigit(ch2);
	System.out.println("Is is a Digit ?   "+flag2);
	
	
	char ch3=95;
	boolean flag3=Character.isLetter(ch3);
	System.out.println("Checking the ASCII code "+flag3);
	
	
		
		
		

	}

}
