package InheritanceConcepts;

class B5
{
	void display()
	{
		System.out.println("Hello");
	}
}

class C5 extends B5
{
	void test()
	{
		System.out.println("I am test method");
	}
}


public class BasicInheritance {

	public static void main(String[] args) {
		
		C5 obj=new C5();
		obj.test();
		obj.display();
		
		

	}

}
