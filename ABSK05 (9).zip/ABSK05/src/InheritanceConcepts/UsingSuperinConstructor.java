package InheritanceConcepts;

class Employee
{
	int id;
	String name;
	
	Employee(int i,String n)
	{
		id=i;
		name=n;
	}
	
	
}
class Manager extends Employee
{
	float salary;
	Manager(int i,String n,float s)
	{
		super(i,n);
		salary=s;
	}
	


void display()
{
	System.out.println(id+"  "+name+"  "+salary);
}
}

public class UsingSuperinConstructor {

	public static void main(String[] args) {
		
		Manager obj=new Manager(1234,"Mark",45000f);
		obj.display();
		

	}

}
