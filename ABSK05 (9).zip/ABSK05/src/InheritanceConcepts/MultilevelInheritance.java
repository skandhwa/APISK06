package InheritanceConcepts;

class D5 
{
	void message()
	{
		System.out.println("This is a messsage method");
	}
}

class E5 extends D5
{
	void test()
	{
		System.out.println("This is a test method");
	}
}


class F5 extends E5
{
	void display()
	{
		System.out.println("This is display method");
	}
}


public class MultilevelInheritance {

	public static void main(String[] args) {
		F5 obj=new F5();
		obj.test();
		obj.display();
		obj.message();

	}

}
