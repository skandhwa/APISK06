package TakingInputFromUser;

import java.util.Scanner;

public class TakingStringAsInput {

	public static void main(String[] args) {
		
		System.out.println("Enter the String you want to find the length");
		Scanner sc=new Scanner(System.in);
		String str;
		
		str=sc.nextLine();
		
		int x=str.length();
		
		
		System.out.println("The length is "+x);
		
		
		
		
		
		

	}

}
