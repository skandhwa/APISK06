package ExceptionHandling;

public class NestedTryCatch {

	public static void main(String[] args) {
	
		try
		{
			try
			{
				System.out.println("I am running a code for divide by zero");
				int x=40/10;
			}
			
			catch(ArithmeticException e)
			{
				System.out.println("caught with "+e);
			}
			
			try
			{
				int b[]=new int[5];
				b[3]=10;
				
				
				
			}
			
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println("caught with "+e);
				
			}
			
			
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		
System.out.println();
		
		int c=20+40;
		System.out.println("The sum of two elements is "+c);
		
		
		
		

	}

}
