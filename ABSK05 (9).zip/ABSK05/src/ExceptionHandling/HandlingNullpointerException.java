package ExceptionHandling;

public class HandlingNullpointerException {

	public static void main(String[] args) {
		
		try
		{
		String str=null;
		
		System.out.println(str.length());
		}
		
		catch(NullPointerException e)
		{
			System.out.println("caught the exception with "+e);
		}
		
         
		
		System.out.println();
		
		int c=20+40;
		System.out.println("The sum of two elements is "+c);
		
		

	}

}
