package ExceptionHandling;

public class FinallyExample {

	public static void main(String[] args) {
		
		try
		{
		int a=20;
		int b=a/2;
		System.out.println(b);
		}
		
		catch(Exception e)
		{
			System.out.println("caught with "+e);
		}
		
		finally
		{
			System.out.println("Always getting executed");
	
		}
		
		
		int x=20;
		int y=30;
		int z=x+y;
		System.out.println(z);
		
		

	}

}
