package ExceptionHandling;

public class HandlingThrowClause {
	
	public static void checkVote(int a)
	{
		if(a<18)
		{
			throw new ArithmeticException("you are not elligible");
		}
		
		else
		{
			System.out.println("You are elligible");
		}
	}
	

	public static void main(String[] args) {
		
		HandlingThrowClause.checkVote(13);
		
		
		
		
		
		

	}

}
