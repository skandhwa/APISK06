package MyPractice1;

import org.testng.Assert;

import MockJsonResponse.JSONResponseData;
import io.restassured.path.json.JsonPath;

public class ValidateResponseMockJson {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(JSONResponseData.CourseDetails());
		
		///Print No of courses returned by API
              
	int courseSize=	js.getInt("courses.size()");
	System.out.println("The total number of courses are  "+courseSize);
		
		///Print Purchase amount
	
int purchaseAmount=	js.getInt("dashboard.purchaseAmount");
System.out.println("The total amount is "+purchaseAmount);

///Print Title of the first course

String title_firstCourse=js.getString("courses[0].title");
System.out.println("Title of first course is  "+title_firstCourse);


///Print All course titles and their respective Prices

System.out.println("All course titles and their respective Prices are below");

for(int i=0;i<courseSize;i++)
{
String courseTitles=	js.getString("courses["+i+"].title");
int coursePrices=	js.getInt("courses["+i+"].price");
System.out.println(courseTitles+"  "+coursePrices);

}


///Print no of copies sold by RPA Course
int copies=js.getInt("courses[2].copies");
System.out.println("Number of copies for RPA are  "+copies);

////Verify if Sum of all Course prices matches with Purchase Amoun

int sum=0;

for(int i=0;i<courseSize;i++)
{
int courseCopies=	js.getInt("courses["+i+"].copies");
int coursePrices=	js.getInt("courses["+i+"].price");
int amount=courseCopies*coursePrices;
sum=sum+amount;

}

Assert.assertEquals(purchaseAmount, sum);

System.out.println("All test cases passed");

		

	}

}
