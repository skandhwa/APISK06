package POJOEx1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException {
		
		RestAssured.baseURI="https://reqres.in/";
		
		EmployeePOJO emp=new EmployeePOJO();
		emp.setName("Harry");
		emp.setAge(35);
		emp.setSalary(50000f);
		emp.setMarried(true);
		
		ObjectMapper obj=new ObjectMapper();
		
		/////Serialization
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	
	
String Response=	given().log().all().body(empJSON).headers("Content-Type","application/json")
	.when().post("api/users")
	.then().log().all().assertThat().statusCode(201).
	extract().response().asString();

System.out.println(Response);

///Deserailization

System.out.println("Doing Deserailization");

EmployeePOJO empObj=obj.readValue(empJSON, EmployeePOJO.class);
	
int age=empObj.getAge();
System.out.println("Age of Employee is "+age);

float salary=empObj.getSalary();
System.out.println("Salary of Employee is "+salary);

	
	
		
		
		

	}

}
