package POJO3Ex;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException {
		
		
		Employee2 emp=new Employee2();
		Employee2 emp1=new Employee2();
		Employee2 emp2=new Employee2();
		
		emp.setName("Harry");
		emp.setAge(35);
		emp.setSalary(50000f);
		emp.setMarried(false);
		
		emp1.setName("Matt");
		emp1.setAge(45);
		emp1.setSalary(60000f);
		emp1.setMarried(true);
		
		
		emp2.setName("John");
		emp2.setAge(55);
		emp2.setSalary(80000f);
		emp2.setMarried(true);
		
		ArrayList<Employee2> emplist=new ArrayList<Employee2>();
		
		emplist.add(emp);
		emplist.add(emp1);
		emplist.add(emp2);
		
		RestAssured.baseURI="https://reqres.in/";
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emplist);
		
		
		String Response=	given().log().all().body(empJSON).headers("Content-Type","application/json")
			.when().post("api/users")
			.then().log().all().assertThat().statusCode(201).
			extract().response().asString();

		System.out.println(Response);

		
		
		

	}

}
