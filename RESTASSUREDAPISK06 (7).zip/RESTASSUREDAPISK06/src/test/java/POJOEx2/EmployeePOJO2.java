package POJOEx2;

public class EmployeePOJO2 {
	
	private String name;
	private int age;
	private float salary;
	private EmployeeAddressPOJO empaddress;
	private boolean isMarried;
	private int id;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public EmployeeAddressPOJO getEmpaddress() {
		return empaddress;
	}
	public void setEmpaddress(EmployeeAddressPOJO empaddress) {
		this.empaddress = empaddress;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	
	
	
	
	

}
