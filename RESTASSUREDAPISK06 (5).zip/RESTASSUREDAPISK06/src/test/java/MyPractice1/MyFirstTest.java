package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class MyFirstTest {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
		
Response res=	given().log().all()
		.when().get("api/users/2")
		.then().log().all().assertThat()
		.statusCode(200).extract().response();

 long time= res.getTime();
 
 System.out.println("The total time is "+time);
 
 int x=res.getStatusCode();
 System.out.println("The status code is  "+x);
 

 
 
 
 


		
		
		
		
		
		
		
		

	}

}
