package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

import org.testng.Assert;

public class MySecondTest {

	public static void main(String[] args) {
		
		int Actual_Page=2;
		String Actual_EMail="michael.lawson@reqres.in";
		
		RestAssured.baseURI="https://reqres.in";
		
	Response res=	given().log().all().queryParam("page", 2)
		.header("Connection","keep-alive")
		.when().get("api/users")
		.then().log().all().assertThat().statusCode(200).extract().response();
		
	
	long time= res.getTime();
	 
	 System.out.println("The total time is "+time);
	 
	 if(time>5000)
	 {
		 throw new ArithmeticException("More than expected time");
	 }
	 
	 
	String ResponseString= res.asString();
	
	JsonPath js=new JsonPath(ResponseString);
	
	int Expaected_Page= js.getInt("page");
	
	
String Expected_email=	js.getString("data[0].email");

Assert.assertEquals(Actual_Page,Expaected_Page);
Assert.assertEquals(Actual_EMail,Expected_email);



	
	
	
	
	 
	 
	 

	}

}
