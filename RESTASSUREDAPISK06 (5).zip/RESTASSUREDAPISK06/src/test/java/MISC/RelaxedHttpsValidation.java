package MISC;
import static io.restassured.RestAssured.*;

public class RelaxedHttpsValidation {

	public static void main(String[] args) {
		
		
String Response=		given().relaxedHTTPSValidation("SSL")
		.log().all().when().get("https://self-signed.badssl.com/")
		.then().extract().response().asString();

System.out.println(Response);
		

///Alternative 
		
		
		

	}

}
