package RequestResponseSpecBuilder;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

import PayloadData.payloadData;

public class Test2 {

	public static void main(String[] args) {
		
		RequestSpecification req= new RequestSpecBuilder()
				.setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON).setRelaxedHTTPSValidation()
				.build();
		
RequestSpecification res=given().log().all().spec(req).
body(payloadData.addDetails("Tom","Manager"));

ResponseSpecification respec=new ResponseSpecBuilder().expectContentType(ContentType.JSON)
.expectStatusCode(201).build();

String Response=res.when().post("api/users").then().spec(respec).
extract().response().asString();

System.out.println(Response);

				
		
		
		

	}

}
