package RequestResponseSpecBuilder;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

public class Test1 {

	public static void main(String[] args) {
		
RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON).build();
		
RequestSpecification res=given().log().all()
				.spec(req);
		
ResponseSpecification respec=new ResponseSpecBuilder().expectContentType(ContentType.JSON).expectStatusCode(200).build();
		
Response response=	res.when().get("api/users/2").then().spec(respec).extract().response();

System.out.println(response.asString());


//
//  long Time=  response.getTime();
//  
//  System.out.println("The total time is "+Time);
//	
 ResponseBody x= response.getBody();
//		
 x.asString();	
				
		
		
		
		
		
		
				
		
		

	}

}
