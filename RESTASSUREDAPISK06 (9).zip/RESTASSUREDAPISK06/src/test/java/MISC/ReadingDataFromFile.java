package MISC;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import org.testng.Assert;

public class ReadingDataFromFile {
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		RestAssured.baseURI="https://httpbin.org";
		File f=new File("‪D:/Payload6.txt");
		
	String filecontent=null;
		Scanner sc=new Scanner(f);
		while(sc.hasNextLine())
		{
			 filecontent=sc.nextLine();
		}
			System.out.println(filecontent);
		
		
		sc.close();
		
		
		
String Response=		given().log().all().headers("Content-Type","multipart/form-data")
		.multiPart("File",f)
		.when().post("post")
		.then().log().all()
		.extract().response().asString();

System.out.println(Response);

JsonPath js=new JsonPath(Response);

String FileData=js.getString("files.File1");

Assert.assertEquals(filecontent,FileData );
		
		
		

	}

}
