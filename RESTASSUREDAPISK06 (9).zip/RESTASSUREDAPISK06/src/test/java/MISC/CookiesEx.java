package MISC;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.response.Response;
public class CookiesEx {

	public static void main(String[] args) {
		RestAssured.baseURI = "https://httpbin.org";

        // Example 1: Sending cookies with request
        Response responseWithCookies = given()
                .cookie("myCookie", "cookieValue123")
                .when()
                .get("/cookies")
                .then()
                .statusCode(200)
                .extract()
                .response();

        System.out.println("Response with sent cookie:\n" + responseWithCookies.getBody().asPrettyString());

        // Example 2: Extracting cookies from a response
        Response response = get("/cookies/set?session_id=abc123&user=JohnDoe");

        // Extract cookies
        Cookies cookies = response.getDetailedCookies();
        System.out.println("\nExtracted Cookies:");

        for (Cookie c : cookies.asList()) {
            System.out.println("Name: " + c.getName());
            System.out.println("Value: " + c.getValue());
            System.out.println("Domain: " + c.getDomain());
            System.out.println("Path: " + c.getPath());
            System.out.println("Is HTTPOnly: " + c.isHttpOnly());
            System.out.println("---------------------------");
        }

	}

}
