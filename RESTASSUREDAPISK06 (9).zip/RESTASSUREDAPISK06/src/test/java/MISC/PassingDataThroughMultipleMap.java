package MISC;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import PayloadData.payloadData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;

public class PassingDataThroughMultipleMap {

	public static void main(String[] args) {
		
		Map<String,Object> mp1=new LinkedHashMap<String,Object>();
		mp1.put("name", "Harry");
		mp1.put("job","Team lead");
		mp1.put("salary",78000f);
		
		Map<String,Object> mp2=new LinkedHashMap<String,Object>();
		mp2.put("name", "Tom");
		mp2.put("job","QA manager");
		mp2.put("salary",88000f);
		
		Map<String,Object> mp3=new LinkedHashMap<String,Object>();
		mp3.put("name", "John");
		mp3.put("job","Analyst");
		mp3.put("salary",98000f);
		
		LinkedList<Map> li=new LinkedList<Map>();
		li.add(mp1);
		li.add(mp2);
		li.add(mp3);
		
		RestAssured.baseURI="https://reqres.in";
		
	String Response=	given().log().all(). body(li).
		headers("Content-Type","application/json")
		.when().post("api/users")
		.then().log().all().extract().response().asString();
	
	System.out.println(Response);
	
	JsonPath js=new JsonPath(Response);
	String sal=	js.getString("[2].salary");
	System.out.println(sal);
		

	}

}
