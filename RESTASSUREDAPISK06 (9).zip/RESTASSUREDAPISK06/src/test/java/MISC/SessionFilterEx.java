package MISC;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;
import io.restassured.filter.session.SessionFilter;

public class SessionFilterEx {
	
	SessionFilter s;
	@BeforeTest
	public SessionFilter captureSessionID()
	{
		s=new SessionFilter();
		return s;
	}
	
	
	@Test
	public void myTest1()
	{
		RestAssured.baseURI="https://httpbin.org";
		
	String Response=	given().log().all().relaxedHTTPSValidation()
		.filter(s)
		.when().get("get").then().extract().response().asString();
		
	}
	
	@Test
	public void myTest2()
	{
		RestAssured.baseURI="https://httpbin.org";
		
	String Response2=	given().log().all().relaxedHTTPSValidation()
		.filter(s)
		.when().get("get").then().extract().response().asString();
		
	}
	
	
	
	
	

	
		
		
		
		

	}


