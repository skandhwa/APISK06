package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class HamcrestMatcher {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://jsonplaceholder.typicode.com";
		
String Response=		given().log().all().when().get("posts/1")
		.then()
		.body("userId", equalTo(1))
		.body("id",equalTo(1))
		.body("title",notNullValue())
		.body("userId", is(1))
		.body("userId", not(2))
		.body("title", startsWith("sunt"))
		.body("title", endsWith("rit"))
		.body("userId", greaterThan(0))
		.body("id", lessThan(10))
		.body("title", matchesPattern("[a-z]"))
		
		
		.extract().response().asString();

System.out.println(Response);

System.out.println("All Validations passed");
		
		
		
		
		
		
		
		
		

	}

}
