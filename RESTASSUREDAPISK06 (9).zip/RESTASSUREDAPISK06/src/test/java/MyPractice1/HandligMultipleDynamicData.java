package MyPractice1;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PayloadData.payloadData;
import io.restassured.RestAssured;

import static io.restassured.RestAssured.*;

public class HandligMultipleDynamicData {
	
	@DataProvider(name="Booksdata")
	public Object [][] getData()
	{
		return new Object [][]
				
				{
			
			{"hbvft","25678","John"},{"knhgt","15678","Tom"},{"hghft","65478","Matt"}
			
				};
	}
	
	@Test(dataProvider="Booksdata")
	public void addBook(String isbn,String aisle,String author)
	{
		RestAssured.baseURI="http://216.10.245.166";
String Response=		given().log().all().headers("content-type","application/json")
		.body(payloadData.AddBook(isbn, aisle,author))
		.when().post("Library/Addbook.php")
		.then().assertThat()
		.statusCode(200).extract().response().asString();


System.out.println(Response);
		
		
		
	}
	
	
	
	
	

}
