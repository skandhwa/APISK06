package MyPractice1;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import static org.hamcrest.Matchers.*;

import static io.restassured.RestAssured.*;

import PayloadData.payloadData;

public class MyFirstPostEx {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
String Response=given().log().all().body(payloadData.addDetails("Tom","Manager")).
headers("Content-Type","application/json")
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201).
		body("job",equalTo("Manager")).
		
		extract().response().asString();
		

System.out.println(Response);

JsonPath js=new JsonPath(Response);

String name=js.getString("name");

System.out.println("The name is  "+name);

		
		

	}

}
