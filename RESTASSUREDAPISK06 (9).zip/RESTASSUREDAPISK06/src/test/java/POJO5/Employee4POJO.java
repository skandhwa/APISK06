package POJO5;

import java.util.List;

import POJO4.EmployeeAddress3POJO;

public class Employee4POJO {
	
	private String name;
	private int age;
	private float salary;
	private EmpAddress4POJO emp4Address;
	private List<String> bank;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public EmpAddress4POJO getEmp4Address() {
		return emp4Address;
	}
	public void setEmp4Address(EmpAddress4POJO emp4Address) {
		this.emp4Address = emp4Address;
	}
	public List<String> getBank() {
		return bank;
	}
	public void setBank(List<String> bank) {
		this.bank = bank;
	}
	
	
	

}
