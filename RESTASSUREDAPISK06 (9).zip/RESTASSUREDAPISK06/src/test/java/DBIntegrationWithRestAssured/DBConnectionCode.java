package DBIntegrationWithRestAssured;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class DBConnectionCode {
	
	@Test
	public static void DBConnection() throws SQLException
	{
		Connection con=null;
		Statement myst=null;
		ResultSet myRs=null;
		Object obj=null;
		
	con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/student2", "root","root");
	System.out.println("Connection established  "+con);	
	
	myst=	con.createStatement();
	
myRs=	myst.executeQuery("select * from student2.persons where city='Hyderabad'");
	
	while(myRs.next())
	{
	obj=	myRs.getString(2);
	}
	
	System.out.println(obj);
	
	
		
		
		
	}
	
	

}
