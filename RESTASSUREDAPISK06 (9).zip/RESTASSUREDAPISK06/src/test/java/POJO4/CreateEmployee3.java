package POJO4;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



import static  io.restassured.RestAssured.*;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class CreateEmployee3 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddress3POJO empAddress=new EmployeeAddress3POJO();
		empAddress.setCity("Mumbai");
		empAddress.setState("Maharastra");
		empAddress.setZip(700033);
		
		List<String> banks=new ArrayList<String>();
		banks.add("SBI");
		banks.add("Axis");
		banks.add("HDFC");
		
		
		Employee3POJO emp=new Employee3POJO();
		emp.setAge(32);
		emp.setName("Harry");
		emp.setSalary(90000f);
		emp.setEmp3Address(empAddress);
		emp.setBank(banks);
		
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
	RestAssured.baseURI="https://reqres.in";
	
	String Response=	given().log().all().body(empJSON).headers("Content-Type","application/json")
			.when().post("api/users")
			.then().log().all().assertThat().statusCode(201).
			extract().response().asString();

		System.out.println(Response);
		
		

		
		
		
		
		
		

	}

}
