package IntegrationWithExcel;

import java.io.IOException;
import java.util.*;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class TestExecutionFromExcel {

	public static void main(String[] args) throws IOException {
		
		FetchDataFromExcelSheet obj=new FetchDataFromExcelSheet(ConstantData.ExcelDataPath1,ConstantData.SheetName);
		
		RestAssured.baseURI=ConstantData.baseURI;
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("name",FetchDataFromExcelSheet.getData(1, 0));
		mp.put("job",FetchDataFromExcelSheet.getData(1, 1));
		mp.put("salary",FetchDataFromExcelSheet.getData(1, 2));
		mp.put("IsMarried",FetchDataFromExcelSheet.getData(1, 3));
		
		
String Response=given().log().all().headers("Content-Type","application/json")
		.body(mp)
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response().asString();

System.out.println(Response);
		
		
		
		
		
				
		
		

	}

}
