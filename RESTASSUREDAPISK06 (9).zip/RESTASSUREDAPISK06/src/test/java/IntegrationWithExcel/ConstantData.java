package IntegrationWithExcel;

public class ConstantData {
	
	public static final String ExcelDataPath1="E:\\TestData10thApril.xlsx";
	public static final String SheetName="Sheet1";
	public static final String baseURI="https://reqres.in";
	
	

}
