package TestData;

public class SqlQueries {
	
	public static String selectQuery1()
	{
		String query1="select * from student2.persons where city='Hyderabad'";
		return query1;
		
	}
	
	public static String selectQuery2()
	{
		String query1="select * from demo.employees where LastName='Das'";
		return query1;
		
	}
	

}
