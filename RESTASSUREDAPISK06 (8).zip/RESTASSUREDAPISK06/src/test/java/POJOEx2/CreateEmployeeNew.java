package POJOEx2;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import POJOEx1.EmployeePOJO;

import static  io.restassured.RestAssured.*;
import io.restassured.response.Response;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateEmployeeNew {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeeAddressPOJO empAddress=new EmployeeAddressPOJO();
		empAddress.setCity("Mumbai");
		empAddress.setState("Maharastra");
		empAddress.setZip(700033);
		
		EmployeePOJO2 empObj=new EmployeePOJO2();
		empObj.setAge(32);
		empObj.setId(3345);
		empObj.setMarried(false);
		empObj.setName("Harry");
		empObj.setSalary(90000f);
		empObj.setEmpaddress(empAddress);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empObj);
		
		
		RequestSpecification req=new RequestSpecBuilder().setBaseUri("https://reqres.in/")
				.setContentType(ContentType.JSON).build();
		
		
		RequestSpecification respec=given().log().all().spec(req).body(empJSON);
		
		ResponseSpecification res=new ResponseSpecBuilder().expectStatusCode(201)
				.expectContentType(ContentType.JSON).build();
		
		
		Response response= respec.when().post("api/users").then().log().all().
				spec(res).extract().response();
		
	long time=	response.getTime();
	System.out.println("The total time is " +time);
	
	if(time>3000)
	{
		throw new ArithmeticException("More time consumed");
	}
	
String responseString=	response.asString();

System.out.println("The Response String is "+responseString);
	 
System.out.println("Doing Deserailization");

EmployeePOJO2 empObjRes=obj.readValue(empJSON, EmployeePOJO2.class);

int age=empObjRes.getAge();
System.out.println("The Age is "+age);









		
				
		
		

	}

}
