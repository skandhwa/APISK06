package POJO5;

import java.util.ArrayList;
import java.util.List;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



import static  io.restassured.RestAssured.*;
import io.restassured.response.Response;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class CreateEmployee4 {

	public static void main(String[] args) throws JsonProcessingException {
		
		HouseDetailsPOJO hd=new HouseDetailsPOJO();
		hd.setFlatno(23);
		hd.setStreet("Pr Mitra Lane");
		
		List<String> li=new ArrayList<String>();
		li.add("ABC Sweets");
		li.add("GK hotel");
		li.add("JK mall");
		
		hd.setLandmark(li);
		
		EmpAddress4POJO empAddress4=new EmpAddress4POJO();
		empAddress4.setCity("Hyderabad");
		empAddress4.setState("Telangana");
		empAddress4.setZip(500066);
		empAddress4.setHdObj(hd);
		
		
		Employee4POJO empObj=new Employee4POJO();
		ArrayList<String> li2=new ArrayList<String>();
		li2.add("SBI");
		li2.add("AXIS");
		li2.add("HDFC");
		
		empObj.setName("Monty");
		empObj.setAge(34);
		empObj.setSalary(90000f);
		empObj.setBank(li2);
		empObj.setEmp4Address(empAddress4);
		
		ObjectMapper obj=new ObjectMapper();
		
		String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(empObj);
		
		
		
		
		
		
		
		

	}

}
