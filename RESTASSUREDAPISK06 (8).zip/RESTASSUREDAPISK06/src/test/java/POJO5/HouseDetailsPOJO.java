package POJO5;

import java.util.List;

public class HouseDetailsPOJO {
	
	private int flatno;
	private String street;
	private List<String> landmark;
	
	
	public int getFlatno() {
		return flatno;
	}
	public void setFlatno(int flatno) {
		this.flatno = flatno;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public List<String> getLandmark() {
		return landmark;
	}
	public void setLandmark(List<String> landmark) {
		this.landmark = landmark;
	}
	
	
	
	
	
	

}
