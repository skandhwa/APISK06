package Authentications;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

public class DigestAuth {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://httpbin.org/digest-auth";
		
	String Response=	given().log().all().auth().digest("saurabh","saurabh")
		.when().get("undefined/saurabh1/saurabh1")
		.then().extract().response().asString();
	
	System.out.println(Response);
		
		
		

	}

}
