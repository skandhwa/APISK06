package POJO4;

import java.util.List;

public class Employee3POJO {
	
	private String name;
	private int age;
	private float salary;
	private EmployeeAddress3POJO emp3Address;
	private List<String> bank;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public EmployeeAddress3POJO getEmp3Address() {
		return emp3Address;
	}
	public void setEmp3Address(EmployeeAddress3POJO emp3Address) {
		this.emp3Address = emp3Address;
	}
	public List<String> getBank() {
		return bank;
	}
	public void setBank(List<String> bank) {
		this.bank = bank;
	}
	
	
	
	
	
	
	

}
