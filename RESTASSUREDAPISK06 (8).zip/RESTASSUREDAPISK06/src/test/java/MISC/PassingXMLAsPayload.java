package MISC;

import io.restassured.RestAssured;
import static io.restassured.RestAssured.*;

import PayloadData.payloadData;

public class PassingXMLAsPayload {

	public static void main(String[] args) {
		
		
		RestAssured.baseURI="https://petstore.swagger.io";
	String Response=	given().log().all().headers("content-type","application/xml")
	.body(payloadData.petData()).when().post("v2/pet")
	.then().log().all().assertThat().statusCode(200)
	.extract().response().asString();
	
	System.out.println(Response);
		
		
		

	}

}
