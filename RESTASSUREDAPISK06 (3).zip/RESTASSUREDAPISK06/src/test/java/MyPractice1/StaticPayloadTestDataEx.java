package MyPractice1;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import PayloadData.payloadData;
import io.restassured.RestAssured;

public class StaticPayloadTestDataEx {

	public static void main(String[] args) throws IOException {
		
		RestAssured.baseURI="https://reqres.in";
		
		String Response=given().log().all().body(new String(Files.readAllBytes(Paths.get("‪E:/TestData25thMarch.txt")))).
		headers("Content-Type","application/json")
				.when().post("api/users")
				.then().log().all().
				assertThat().statusCode(201).
				
				
				extract().response().asString();
				

		System.out.println(Response);
		
		

	}

}
